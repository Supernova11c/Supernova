import { Link } from 'wouter';
import logoPath from '@assets/Supernova_1784039682567.png';

interface HeaderProps {
  showSearch?: boolean;
  compact?: boolean;
}

export function Header({ showSearch = false, compact = false }: HeaderProps) {
  return (
    <header className="border-b border-border bg-background/80 backdrop-blur-sm sticky top-0 z-40">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
          <img src={logoPath} alt="Supernova" className="h-8 w-8" />
          <span className="font-display font-bold text-xl">Supernova</span>
        </Link>

        <nav className="flex items-center gap-6">
          <Link
            href="/discovery"
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Discovery
          </Link>
          <Link
            href="/privacy"
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Privacy
          </Link>
          <Link
            href="/admin"
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Admin
          </Link>
        </nav>
      </div>
    </header>
  );
}
