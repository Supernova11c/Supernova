import { useState } from 'react';
import { SearchResult as SearchResultType } from '@workspace/api-client-react';
import { MoreVertical, Flag, AlertCircle, ExternalLink, CheckCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useSubmitFeedback, useSubmitSpamReport, FeedbackType } from '@workspace/api-client-react';
import { useToast } from '@/hooks/use-toast';

interface SearchResultProps {
  result: SearchResultType;
  index: number;
}

export function SearchResult({ result, index }: SearchResultProps) {
  const [feedbackOpen, setFeedbackOpen] = useState(false);
  const [spamOpen, setSpamOpen] = useState(false);
  const [feedbackType, setFeedbackType] = useState<FeedbackType>('irrelevant');
  const [comment, setComment] = useState('');
  const [spamReason, setSpamReason] = useState('');
  const { toast } = useToast();

  const submitFeedback = useSubmitFeedback();
  const submitSpamReport = useSubmitSpamReport();

  const handleFeedbackSubmit = () => {
    submitFeedback.mutate(
      {
        data: {
          query: new URLSearchParams(window.location.search).get('q') || '',
          url: result.url,
          type: feedbackType,
          comment: comment || null,
        },
      },
      {
        onSuccess: () => {
          toast({ title: 'Feedback submitted', description: 'Thank you for your feedback.' });
          setFeedbackOpen(false);
          setComment('');
        },
        onError: () => {
          toast({
            title: 'Failed to submit feedback',
            description: 'Please try again.',
            variant: 'destructive',
          });
        },
      }
    );
  };

  const handleSpamSubmit = () => {
    if (!spamReason.trim()) {
      toast({ title: 'Please provide a reason', variant: 'destructive' });
      return;
    }

    submitSpamReport.mutate(
      {
        data: {
          url: result.url,
          reason: spamReason,
        },
      },
      {
        onSuccess: () => {
          toast({ title: 'Spam report submitted', description: 'Thank you for helping improve search quality.' });
          setSpamOpen(false);
          setSpamReason('');
        },
        onError: () => {
          toast({
            title: 'Failed to submit report',
            description: 'Please try again.',
            variant: 'destructive',
          });
        },
      }
    );
  };

  return (
    <>
      <div
        data-testid={`result-${result.id}`}
        className={cn('group', index < 10 ? `stagger-${index + 1}` : 'animate-fade-in-up')}
      >
        <div className="flex gap-4">
          {result.thumbnailUrl && (
            <img
              src={result.thumbnailUrl}
              alt={result.title}
              className="w-24 h-24 rounded-lg object-cover shrink-0 bg-muted"
            />
          )}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2 mb-1">
              <div className="flex items-center gap-2 min-w-0">
                <a
                  href={result.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1.5 truncate"
                >
                  <span className="truncate">{result.domain}</span>
                  <ExternalLink className="w-3 h-3 shrink-0" />
                </a>
                {result.isDirectNav ? (
                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/10 border border-primary/20">
                    <CheckCircle className="w-3 h-3 text-primary" />
                    <span className="text-xs text-primary">Official site</span>
                  </div>
                ) : (
                  result.isTrusted && (
                    <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-500/10 border border-green-500/20">
                      <CheckCircle className="w-3 h-3 text-green-500" />
                      <span className="text-xs text-green-600 dark:text-green-400">Trusted</span>
                    </div>
                  )
                )}
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    data-testid={`button-result-menu-${result.id}`}
                    className="h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <MoreVertical className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => setFeedbackOpen(true)}>
                    <AlertCircle className="w-4 h-4 mr-2" />
                    Report issue
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSpamOpen(true)}>
                    <Flag className="w-4 h-4 mr-2" />
                    Report spam
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <a
              href={result.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block group/link"
            >
              <h3 className="text-xl font-medium text-primary group-hover/link:underline mb-1 line-clamp-2">
                {result.title}
              </h3>
              <p className="text-sm text-foreground/80 line-clamp-2 mb-2">{result.description}</p>
              {result.snippet && (
                <p className="text-sm text-muted-foreground line-clamp-2">{result.snippet}</p>
              )}
            </a>

            {result.publishedAt && (
              <p className="text-xs text-muted-foreground mt-2">
                {new Date(result.publishedAt).toLocaleDateString()}
              </p>
            )}
          </div>
        </div>
      </div>

      <Dialog open={feedbackOpen} onOpenChange={setFeedbackOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Report an issue with this result</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Issue type</Label>
              <RadioGroup value={feedbackType} onValueChange={(v) => setFeedbackType(v as FeedbackType)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="irrelevant" id="irrelevant" />
                  <Label htmlFor="irrelevant">Irrelevant to my search</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="broken_link" id="broken_link" />
                  <Label htmlFor="broken_link">Broken link</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="wrong_info" id="wrong_info" />
                  <Label htmlFor="wrong_info">Contains wrong information</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="other" id="other" />
                  <Label htmlFor="other">Other</Label>
                </div>
              </RadioGroup>
            </div>
            <div className="space-y-2">
              <Label htmlFor="comment">Additional details (optional)</Label>
              <Textarea
                id="comment"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Tell us more about the issue..."
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFeedbackOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleFeedbackSubmit} disabled={submitFeedback.isPending}>
              Submit feedback
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={spamOpen} onOpenChange={setSpamOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Report spam or low-quality content</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="spam-reason">Why is this spam?</Label>
              <Textarea
                id="spam-reason"
                value={spamReason}
                onChange={(e) => setSpamReason(e.target.value)}
                placeholder="Describe why this result should be removed from the index..."
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSpamOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSpamSubmit} disabled={submitSpamReport.isPending}>
              Submit report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
