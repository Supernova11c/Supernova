import { useState, useEffect, useRef } from 'react';
import { Search, X } from 'lucide-react';
import { useLocation } from 'wouter';
import { useSuggest } from '@workspace/api-client-react';
import { cn } from '@/lib/utils';

interface SearchBarProps {
  initialQuery?: string;
  autoFocus?: boolean;
  size?: 'default' | 'large';
  onSearch?: (query: string) => void;
}

export function SearchBar({ initialQuery = '', autoFocus = false, size = 'default', onSearch }: SearchBarProps) {
  const [query, setQuery] = useState(initialQuery);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [, setLocation] = useLocation();
  const inputRef = useRef<HTMLInputElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  const { data: suggestionsData } = useSuggest(
    { q: query },
    { query: { enabled: query.length > 0 && showSuggestions } }
  );

  const suggestions = suggestionsData?.suggestions || [];

  useEffect(() => {
    if (autoFocus && inputRef.current) {
      inputRef.current.focus();
    }
  }, [autoFocus]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      setShowSuggestions(false);
      if (onSearch) {
        onSearch(query);
      } else {
        setLocation(`/search?q=${encodeURIComponent(query)}`);
      }
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setQuery(suggestion);
    setShowSuggestions(false);
    if (onSearch) {
      onSearch(suggestion);
    } else {
      setLocation(`/search?q=${encodeURIComponent(suggestion)}`);
    }
  };

  const handleClear = () => {
    setQuery('');
    inputRef.current?.focus();
  };

  return (
    <div ref={wrapperRef} className="relative w-full">
      <form onSubmit={handleSubmit} className="relative rainbow-glow rounded-xl">
        <div
          className={cn(
            'relative flex items-center bg-card border border-input rounded-xl transition-all duration-200',
            size === 'large' ? 'h-16' : 'h-12',
            showSuggestions && suggestions.length > 0 && 'rounded-b-none border-b-0'
          )}
          style={{
            boxShadow: showSuggestions
              ? '0 0 0 2px hsl(var(--primary) / 0.2)'
              : undefined,
          }}
        >
          <Search
            className={cn(
              'absolute left-4 text-muted-foreground',
              size === 'large' ? 'w-6 h-6' : 'w-5 h-5'
            )}
          />
          <input
            ref={inputRef}
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setShowSuggestions(true)}
            placeholder="Search the web..."
            data-testid="input-search"
            className={cn(
              'flex-1 bg-transparent outline-none text-foreground placeholder:text-muted-foreground w-full',
              size === 'large' ? 'text-lg px-14' : 'text-base px-12'
            )}
          />
          {query && (
            <button
              type="button"
              onClick={handleClear}
              data-testid="button-clear-search"
              className="absolute right-4 p-1 rounded-lg hover:bg-muted transition-colors"
            >
              <X className={cn(size === 'large' ? 'w-5 h-5' : 'w-4 h-4')} />
            </button>
          )}
        </div>
      </form>

      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 bg-card border border-input border-t-0 rounded-b-xl overflow-hidden z-50 shadow-lg">
          {suggestions.map((suggestion, idx) => (
            <button
              key={idx}
              onClick={() => handleSuggestionClick(suggestion)}
              data-testid={`suggestion-${idx}`}
              className="w-full px-4 py-3 text-left hover:bg-muted transition-colors flex items-center gap-3 text-sm"
            >
              <Search className="w-4 h-4 text-muted-foreground" />
              <span>{suggestion}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
