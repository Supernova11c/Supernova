import { useState } from 'react';
import { AiOverview } from '@workspace/api-client-react';
import { Sparkles, ChevronDown, ChevronUp, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Link } from 'wouter';

interface AiOverviewPanelProps {
  overview: AiOverview;
  onCitationClick?: (index: number) => void;
}

export function AiOverviewPanel({ overview, onCitationClick }: AiOverviewPanelProps) {
  const [isExpanded, setIsExpanded] = useState(true);

  const confidenceColor = {
    high: 'text-green-500',
    medium: 'text-yellow-500',
    low: 'text-orange-500',
  }[overview.confidence];

  const confidenceLabel = {
    high: 'High confidence',
    medium: 'Medium confidence',
    low: 'Low confidence',
  }[overview.confidence];

  const renderAnswerWithCitations = () => {
    const parts = overview.answer.split(/(\[\d+\])/g);
    return parts.map((part, idx) => {
      const match = part.match(/\[(\d+)\]/);
      if (match) {
        const citationIndex = parseInt(match[1]);
        const citation = overview.citations.find((c) => c.index === citationIndex);
        return (
          <button
            key={idx}
            onClick={() => onCitationClick?.(citationIndex)}
            data-testid={`citation-badge-${citationIndex}`}
            className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-medium hover:ring-2 hover:ring-primary/30 transition-all mx-0.5 align-baseline"
            title={citation?.title || ''}
          >
            {citationIndex}
          </button>
        );
      }
      return <span key={idx}>{part}</span>;
    });
  };

  return (
    <div className="bg-card border border-card-border rounded-xl overflow-hidden shadow-sm">
      <div
        className="px-6 py-4 flex items-center justify-between cursor-pointer hover:bg-muted/50 transition-colors"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="font-display font-semibold text-lg">AI Overview</h2>
            <p className="text-xs text-muted-foreground">
              {confidenceLabel} · {overview.grounded ? 'Grounded in indexed sources' : 'Synthesized'}
            </p>
          </div>
        </div>
        <button
          data-testid="button-toggle-overview"
          className="p-2 rounded-lg hover:bg-muted transition-colors"
        >
          {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
      </div>

      {isExpanded && (
        <div className="px-6 pb-6 space-y-6">
          <div className="prose prose-sm dark:prose-invert max-w-none">
            <p className="text-foreground leading-relaxed">{renderAnswerWithCitations()}</p>
          </div>

          {overview.citations.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">Sources</h3>
              <div className="grid gap-2">
                {overview.citations.map((citation) => (
                  <a
                    key={citation.index}
                    href={citation.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-testid={`citation-source-${citation.index}`}
                    className="flex items-start gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors group"
                  >
                    <div className="flex items-center justify-center w-6 h-6 rounded-full bg-primary text-primary-foreground text-xs font-medium shrink-0 mt-0.5">
                      {citation.index}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium group-hover:text-primary transition-colors line-clamp-1">
                        {citation.title}
                      </p>
                      <p className="text-xs text-muted-foreground line-clamp-1">{citation.url}</p>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          )}

          {overview.followUpQuestions.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">People also ask</h3>
              <div className="grid gap-2">
                {overview.followUpQuestions.map((question, idx) => (
                  <Link
                    key={idx}
                    href={`/search?q=${encodeURIComponent(question)}`}
                    data-testid={`followup-${idx}`}
                    className="px-4 py-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors text-sm text-left"
                  >
                    {question}
                  </Link>
                ))}
              </div>
            </div>
          )}

          {!overview.grounded && (
            <div className="flex items-start gap-2 p-3 rounded-lg bg-orange-500/10 border border-orange-500/20">
              <AlertCircle className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
              <p className="text-xs text-orange-600 dark:text-orange-400">
                This answer was synthesized from available data but may not be fully grounded in indexed sources.
                Verify critical information independently.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
