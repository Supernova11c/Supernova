import { SearchBar } from '@/components/SearchBar';
import { useGetTrending } from '@workspace/api-client-react';
import logoPath from '@assets/Supernova_1784039682567.png';
import { Link } from 'wouter';

export default function Home() {
  const { data: trendingData } = useGetTrending();
  const trending = trendingData?.queries || [];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <div className="absolute top-6 right-6">
        <nav className="flex items-center gap-6">
          <Link
            href="/privacy"
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Privacy
          </Link>
          <Link
            href="/admin"
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Admin
          </Link>
        </nav>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-4 -mt-20">
        <div className="w-full max-w-2xl space-y-12 animate-fade-in-up">
          <div className="text-center space-y-4">
            <div className="flex justify-center mb-6">
              <div className="relative h-24 w-24 rounded-full">
                <div className="rainbow-glow-static absolute inset-0 rounded-full" />
                <img
                  src={logoPath}
                  alt="Supernova"
                  className="relative h-24 w-24 rounded-full"
                />
              </div>
            </div>
            <h1 className="font-display font-bold text-5xl md:text-6xl tracking-tight">
              Supernova Search
            </h1>
            <p className="text-xl text-muted-foreground max-w-lg mx-auto">
              Privacy-first, AI-powered search. Zero tracking. Zero ads. Built for Nepal, designed
              for the world.
            </p>
          </div>

          <SearchBar size="large" autoFocus />

          {trending.length > 0 && (
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground text-center">Trending searches</p>
              <div className="flex flex-wrap justify-center gap-2">
                {trending.slice(0, 6).map((query, idx) => (
                  <Link
                    key={idx}
                    href={`/search?q=${encodeURIComponent(query)}`}
                    data-testid={`trending-${idx}`}
                    className="px-4 py-2 rounded-full bg-card border border-border hover:border-primary hover:bg-card/80 transition-all text-sm"
                  >
                    {query}
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <footer className="py-8 text-center text-sm text-muted-foreground">
        <p>
          No tracking. No ads. No BS. Your searches are private and never stored with identifiable
          information.
        </p>
      </footer>
    </div>
  );
}
