import { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import {
  useGetAdminStats,
  useGetAdminHealth,
  useListCrawlJobs,
  useSubmitCrawlUrl,
  useReindexAll,
  useListErrorLogs,
  useListFeedback,
  useUpdateFeedbackStatus,
  useListSpamReports,
  useUpdateSpamReportStatus,
  CrawlJobStatus,
  FeedbackStatus,
  SpamReportStatus,
  getGetAdminStatsQueryKey,
  getListCrawlJobsQueryKey,
  getListFeedbackQueryKey,
  getListSpamReportsQueryKey,
} from '@workspace/api-client-react';
import { setAuthTokenGetter } from '@workspace/api-client-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2, CheckCircle, AlertCircle, XCircle, Activity, Database, Bot } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQueryClient } from '@tanstack/react-query';
import { cn } from '@/lib/utils';

export default function Admin() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [adminKey, setAdminKey] = useState('');
  const [crawlUrl, setCrawlUrl] = useState('');
  const [statusFilter, setStatusFilter] = useState<CrawlJobStatus | undefined>(undefined);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  useEffect(() => {
    const storedKey = localStorage.getItem('supernova_admin_key');
    if (storedKey) {
      setAuthTokenGetter(() => storedKey);
      setIsAuthenticated(true);
    }
  }, []);

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminKey.trim()) {
      localStorage.setItem('supernova_admin_key', adminKey);
      setAuthTokenGetter(() => adminKey);
      setIsAuthenticated(true);
      toast({ title: 'Admin access granted' });
    }
  };

  const { data: stats, isLoading: statsLoading } = useGetAdminStats({
    query: { enabled: isAuthenticated },
  });
  const { data: health, isLoading: healthLoading } = useGetAdminHealth({
    query: { enabled: isAuthenticated },
  });
  const { data: crawlJobs, isLoading: jobsLoading } = useListCrawlJobs(statusFilter, {
    query: { enabled: isAuthenticated },
  });
  const { data: errorLogs, isLoading: logsLoading } = useListErrorLogs({
    query: { enabled: isAuthenticated },
  });
  const { data: feedbackList, isLoading: feedbackLoading } = useListFeedback({
    query: { enabled: isAuthenticated },
  });
  const { data: spamReports, isLoading: spamLoading } = useListSpamReports({
    query: { enabled: isAuthenticated },
  });

  const submitCrawl = useSubmitCrawlUrl();
  const reindexAll = useReindexAll();
  const updateFeedback = useUpdateFeedbackStatus();
  const updateSpam = useUpdateSpamReportStatus();

  const handleSubmitCrawl = (e: React.FormEvent) => {
    e.preventDefault();
    submitCrawl.mutate(
      { data: { url: crawlUrl } },
      {
        onSuccess: () => {
          toast({ title: 'Crawl job submitted' });
          setCrawlUrl('');
          queryClient.invalidateQueries({ queryKey: getListCrawlJobsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
        },
        onError: () => {
          toast({ title: 'Failed to submit crawl', variant: 'destructive' });
        },
      }
    );
  };

  const handleReindexAll = () => {
    if (confirm('Are you sure you want to reindex all documents? This may take a while.')) {
      reindexAll.mutate(
        {},
        {
          onSuccess: (data) => {
            toast({
              title: 'Reindex started',
              description: `${data.queued} documents queued for reindexing`,
            });
            queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
          },
          onError: () => {
            toast({ title: 'Failed to start reindex', variant: 'destructive' });
          },
        }
      );
    }
  };

  const handleFeedbackUpdate = (id: number, status: FeedbackStatus) => {
    updateFeedback.mutate(
      { id, data: { status } },
      {
        onSuccess: () => {
          toast({ title: 'Feedback updated' });
          queryClient.invalidateQueries({ queryKey: getListFeedbackQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
        },
      }
    );
  };

  const handleSpamUpdate = (id: number, status: SpamReportStatus) => {
    updateSpam.mutate(
      { id, data: { status } },
      {
        onSuccess: () => {
          toast({ title: 'Spam report updated' });
          queryClient.invalidateQueries({ queryKey: getListSpamReportsQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetAdminStatsQueryKey() });
        },
      }
    );
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-12 max-w-md">
          <Card>
            <CardHeader>
              <CardTitle>Admin Access</CardTitle>
              <CardDescription>Enter your admin key to continue</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAuth} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="admin-key">Admin Key</Label>
                  <Input
                    id="admin-key"
                    type="password"
                    value={adminKey}
                    onChange={(e) => setAdminKey(e.target.value)}
                    placeholder="Enter admin key"
                    data-testid="input-admin-key"
                  />
                </div>
                <Button type="submit" className="w-full" data-testid="button-admin-login">
                  Access Dashboard
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const healthStatus = (status: string) => {
    switch (status) {
      case 'ok':
        return { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-500/10' };
      case 'degraded':
        return { icon: AlertCircle, color: 'text-yellow-500', bg: 'bg-yellow-500/10' };
      case 'down':
        return { icon: XCircle, color: 'text-red-500', bg: 'bg-red-500/10' };
      default:
        return { icon: AlertCircle, color: 'text-muted-foreground', bg: 'bg-muted' };
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display font-bold text-3xl mb-2">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor system health, manage crawls, and moderate content
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview" data-testid="tab-overview">
              Overview
            </TabsTrigger>
            <TabsTrigger value="crawls" data-testid="tab-crawls">
              Crawl Jobs
            </TabsTrigger>
            <TabsTrigger value="moderation" data-testid="tab-moderation">
              Moderation
            </TabsTrigger>
            <TabsTrigger value="errors" data-testid="tab-errors">
              Error Logs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {healthLoading || statsLoading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : (
              <>
                <div className="grid gap-6 md:grid-cols-3">
                  {health && (
                    <>
                      {[
                        { label: 'Database', status: health.database, icon: Database },
                        { label: 'Crawler', status: health.crawler, icon: Activity },
                        { label: 'AI Overview', status: health.aiOverview, icon: Bot },
                      ].map((item) => {
                        const statusInfo = healthStatus(item.status);
                        const Icon = item.icon;
                        return (
                          <Card key={item.label}>
                            <CardHeader className="pb-3">
                              <CardTitle className="text-base flex items-center gap-2">
                                <Icon className="w-4 h-4" />
                                {item.label}
                              </CardTitle>
                            </CardHeader>
                            <CardContent>
                              <div
                                className={cn(
                                  'flex items-center gap-2 px-3 py-2 rounded-lg',
                                  statusInfo.bg
                                )}
                              >
                                <statusInfo.icon className={cn('w-5 h-5', statusInfo.color)} />
                                <span className={cn('font-medium capitalize', statusInfo.color)}>
                                  {item.status}
                                </span>
                              </div>
                            </CardContent>
                          </Card>
                        );
                      })}
                    </>
                  )}
                </div>

                {stats && (
                  <>
                    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm">Total Pages</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-3xl font-bold">
                            {stats.crawl.totalPages.toLocaleString()}
                          </p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm">Total Domains</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-3xl font-bold">
                            {stats.crawl.totalDomains.toLocaleString()}
                          </p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm">Queue Size</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-3xl font-bold">
                            {stats.crawl.queueSize.toLocaleString()}
                          </p>
                        </CardContent>
                      </Card>
                      <Card>
                        <CardHeader className="pb-3">
                          <CardTitle className="text-sm">Indexed Today</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-3xl font-bold">
                            {stats.crawl.indexedToday.toLocaleString()}
                          </p>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="grid gap-6 md:grid-cols-2">
                      <Card>
                        <CardHeader>
                          <CardTitle>Documents by Type</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {Object.entries(stats.index.byContentType).map(([type, count]) => (
                              <div key={type} className="flex items-center justify-between">
                                <span className="text-sm capitalize">{type}</span>
                                <Badge variant="outline">{count.toLocaleString()}</Badge>
                              </div>
                            ))}
                          </div>
                        </CardContent>
                      </Card>

                      <Card>
                        <CardHeader>
                          <CardTitle>Documents by Language</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-2">
                            {Object.entries(stats.index.byLanguage)
                              .sort(([, a], [, b]) => b - a)
                              .slice(0, 5)
                              .map(([lang, count]) => (
                                <div key={lang} className="flex items-center justify-between">
                                  <span className="text-sm uppercase">{lang}</span>
                                  <Badge variant="outline">{count.toLocaleString()}</Badge>
                                </div>
                              ))}
                          </div>
                        </CardContent>
                      </Card>
                    </div>

                    <Card>
                      <CardHeader>
                        <CardTitle>Actions</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <Button
                          onClick={handleReindexAll}
                          disabled={reindexAll.isPending}
                          data-testid="button-reindex-all"
                        >
                          {reindexAll.isPending && (
                            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          )}
                          Reindex All
                        </Button>
                      </CardContent>
                    </Card>
                  </>
                )}
              </>
            )}
          </TabsContent>

          <TabsContent value="crawls" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Submit URL for Crawling</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitCrawl} className="flex gap-3">
                  <Input
                    value={crawlUrl}
                    onChange={(e) => setCrawlUrl(e.target.value)}
                    placeholder="https://example.com"
                    data-testid="input-crawl-url"
                    className="flex-1"
                  />
                  <Button
                    type="submit"
                    disabled={submitCrawl.isPending}
                    data-testid="button-submit-crawl"
                  >
                    {submitCrawl.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                    Submit
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Crawl Jobs</CardTitle>
                  <Select
                    value={statusFilter || 'all'}
                    onValueChange={(v) => setStatusFilter(v === 'all' ? undefined : (v as CrawlJobStatus))}
                  >
                    <SelectTrigger className="w-40" data-testid="select-status-filter">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All statuses</SelectItem>
                      <SelectItem value="queued">Queued</SelectItem>
                      <SelectItem value="crawling">Crawling</SelectItem>
                      <SelectItem value="indexed">Indexed</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                      <SelectItem value="blocked">Blocked</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent>
                {jobsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>URL</TableHead>
                        <TableHead>Domain</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Discovered</TableHead>
                        <TableHead>Crawled</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {crawlJobs?.map((job) => (
                        <TableRow key={job.id} data-testid={`crawl-job-${job.id}`}>
                          <TableCell className="max-w-xs truncate">{job.url}</TableCell>
                          <TableCell>{job.domain}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                job.status === 'indexed'
                                  ? 'default'
                                  : job.status === 'failed'
                                  ? 'destructive'
                                  : 'outline'
                              }
                            >
                              {job.status}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {new Date(job.discoveredAt).toLocaleString()}
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {job.crawledAt ? new Date(job.crawledAt).toLocaleString() : '—'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="moderation" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>User Feedback ({stats?.openFeedback || 0} open)</CardTitle>
              </CardHeader>
              <CardContent>
                {feedbackLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Query</TableHead>
                        <TableHead>URL</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Comment</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {feedbackList?.map((feedback) => (
                        <TableRow key={feedback.id} data-testid={`feedback-${feedback.id}`}>
                          <TableCell>{feedback.query}</TableCell>
                          <TableCell className="max-w-xs truncate">{feedback.url || '—'}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{feedback.type.replace('_', ' ')}</Badge>
                          </TableCell>
                          <TableCell className="max-w-xs truncate">
                            {feedback.comment || '—'}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                feedback.status === 'resolved'
                                  ? 'default'
                                  : feedback.status === 'dismissed'
                                  ? 'outline'
                                  : 'secondary'
                              }
                            >
                              {feedback.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {feedback.status === 'open' && (
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleFeedbackUpdate(feedback.id, 'resolved')}
                                  data-testid={`button-resolve-${feedback.id}`}
                                >
                                  Resolve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleFeedbackUpdate(feedback.id, 'dismissed')}
                                  data-testid={`button-dismiss-${feedback.id}`}
                                >
                                  Dismiss
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Spam Reports ({stats?.openSpamReports || 0} open)</CardTitle>
              </CardHeader>
              <CardContent>
                {spamLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>URL</TableHead>
                        <TableHead>Reason</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {spamReports?.map((report) => (
                        <TableRow key={report.id} data-testid={`spam-${report.id}`}>
                          <TableCell className="max-w-xs truncate">{report.url}</TableCell>
                          <TableCell className="max-w-sm">{report.reason}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                report.status === 'removed'
                                  ? 'destructive'
                                  : report.status === 'dismissed'
                                  ? 'outline'
                                  : 'secondary'
                              }
                            >
                              {report.status}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {report.status === 'open' && (
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleSpamUpdate(report.id, 'removed')}
                                  data-testid={`button-remove-${report.id}`}
                                >
                                  Remove
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleSpamUpdate(report.id, 'dismissed')}
                                  data-testid={`button-dismiss-spam-${report.id}`}
                                >
                                  Dismiss
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="errors" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Error Logs</CardTitle>
              </CardHeader>
              <CardContent>
                {logsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-6 h-6 animate-spin text-primary" />
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Level</TableHead>
                        <TableHead>Message</TableHead>
                        <TableHead>URL</TableHead>
                        <TableHead>Time</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {errorLogs?.map((log) => (
                        <TableRow key={log.id} data-testid={`error-${log.id}`}>
                          <TableCell>
                            <Badge
                              variant={
                                log.level === 'error' ? 'destructive' : log.level === 'warn' ? 'outline' : 'secondary'
                              }
                            >
                              {log.level}
                            </Badge>
                          </TableCell>
                          <TableCell className="max-w-md">{log.message}</TableCell>
                          <TableCell className="max-w-xs truncate">{log.url || '—'}</TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {new Date(log.createdAt).toLocaleString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
