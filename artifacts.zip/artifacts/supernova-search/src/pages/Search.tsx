import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { keepPreviousData } from '@tanstack/react-query';
import { Header } from '@/components/Header';
import { SearchBar } from '@/components/SearchBar';
import { AiOverviewPanel } from '@/components/AiOverviewPanel';
import { SearchResult } from '@/components/SearchResult';
import { useSearch, useGetAiOverview, ContentType } from '@workspace/api-client-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Link } from 'wouter';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { useGeoSearch } from '@workspace/api-client-react';
import { Loader2 } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { cn } from '@/lib/utils';

// Fix Leaflet default icon issue
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

export default function Search() {
  const [location, setLocation] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const query = params.get('q') || '';
  const typeParam = (params.get('type') || 'web') as ContentType;

  const [activeType, setActiveType] = useState<ContentType>(typeParam);
  const resultRefs = useRef<{ [key: number]: HTMLElement | null }>({});

  // placeholderData: keepPreviousData means switching tabs (Web -> Images ->
  // Web, etc.) keeps showing the previous tab's results while the new ones
  // load in the background, instead of blanking the page behind a
  // full-screen spinner on every click — that's what made tab-switching
  // feel slow. Combined with the 30s staleTime on the query client, jumping
  // back to a tab you already visited is instant (served from cache, no
  // network round-trip at all).
  const {
    data: searchData,
    isLoading: searchLoading,
    isFetching: searchFetching,
  } = useSearch(
    { q: query, type: activeType },
    { query: { enabled: !!query, placeholderData: keepPreviousData } }
  );

  const { data: aiOverview, isLoading: aiLoading } = useGetAiOverview(
    { q: query },
    {
      query: {
        enabled: !!query && activeType === 'web',
        placeholderData: keepPreviousData,
      },
    }
  );

  const { data: geoData, isLoading: geoLoading } = useGeoSearch(
    { q: query },
    { query: { enabled: !!query && activeType === 'map', placeholderData: keepPreviousData } }
  );

  useEffect(() => {
    setActiveType(typeParam);
  }, [typeParam]);

  const handleTypeChange = (type: string) => {
    const newParams = new URLSearchParams(params);
    newParams.set('type', type);
    setLocation(`/search?${newParams.toString()}`);
  };

  const handleSearch = (newQuery: string) => {
    const newParams = new URLSearchParams();
    newParams.set('q', newQuery);
    newParams.set('type', activeType);
    setLocation(`/search?${newParams.toString()}`);
  };

  const handleCitationClick = (index: number) => {
    const result = searchData?.results?.find((r) =>
      aiOverview?.citations.some((c) => c.index === index && c.url === r.url)
    );
    if (result && resultRefs.current[result.id]) {
      resultRefs.current[result.id]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      resultRefs.current[result.id]?.classList.add('ring-2', 'ring-primary', 'rounded-xl');
      setTimeout(() => {
        resultRefs.current[result.id]?.classList.remove('ring-2', 'ring-primary', 'rounded-xl');
      }, 2000);
    }
  };

  const results = searchData?.results || [];
  const relatedSearches = searchData?.relatedSearches || [];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-6">
        <div className="max-w-3xl mb-6">
          <SearchBar initialQuery={query} onSearch={handleSearch} />
        </div>

        <Tabs value={activeType} onValueChange={handleTypeChange} className="mb-6">
          <TabsList>
            <TabsTrigger value="web" data-testid="tab-web">
              Web
            </TabsTrigger>
            <TabsTrigger value="image" data-testid="tab-images">
              Images
            </TabsTrigger>
            <TabsTrigger value="video" data-testid="tab-videos">
              Videos
            </TabsTrigger>
            <TabsTrigger value="news" data-testid="tab-news">
              News
            </TabsTrigger>
            <TabsTrigger value="map" data-testid="tab-maps">
              Maps
            </TabsTrigger>
            <TabsTrigger value="pdf" data-testid="tab-pdfs">
              PDF
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {(searchLoading && !searchData) || (aiLoading && activeType === 'web' && !aiOverview) ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {activeType === 'web' && searchData && (
              <div className={cn('space-y-6 transition-opacity', searchFetching && 'opacity-60')}>
                <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                  <span>
                    About {searchData.total.toLocaleString()} results ({searchData.tookMs}ms)
                  </span>
                </div>

                {aiOverview && (
                  <div className="mb-8">
                    <AiOverviewPanel overview={aiOverview} onCitationClick={handleCitationClick} />
                  </div>
                )}

                <div className="space-y-8">
                  {results.map((result, idx) => (
                    <div
                      key={result.id}
                      ref={(el) => {
                        resultRefs.current[result.id] = el;
                      }}
                      className="transition-all duration-300"
                    >
                      <SearchResult result={result} index={idx} />
                    </div>
                  ))}
                </div>

                {relatedSearches.length > 0 && (
                  <div className="mt-12 space-y-4">
                    <h3 className="text-lg font-display font-semibold">Related searches</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {relatedSearches.map((related, idx) => (
                        <Link
                          key={idx}
                          href={`/search?q=${encodeURIComponent(related)}&type=${activeType}`}
                          data-testid={`related-${idx}`}
                          className="px-4 py-3 rounded-lg bg-card border border-border hover:border-primary hover:bg-card/80 transition-all"
                        >
                          {related}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeType === 'map' && (
              <div className="space-y-6">
                {geoLoading ? (
                  <div className="flex items-center justify-center py-20">
                    <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  </div>
                ) : geoData?.places && geoData.places.length > 0 ? (
                  <>
                    <div className="h-[500px] rounded-xl overflow-hidden border border-border">
                      <MapContainer
                        center={[geoData.places[0].lat, geoData.places[0].lon]}
                        zoom={13}
                        style={{ height: '100%', width: '100%' }}
                      >
                        <TileLayer
                          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        />
                        {geoData.places.map((place, idx) => (
                          <Marker key={idx} position={[place.lat, place.lon]}>
                            <Popup>
                              <div className="text-sm">
                                <p className="font-semibold">{place.name}</p>
                                <p className="text-muted-foreground text-xs">{place.displayName}</p>
                              </div>
                            </Popup>
                          </Marker>
                        ))}
                      </MapContainer>
                    </div>

                    <div className="space-y-3">
                      {geoData.places.map((place, idx) => (
                        <div
                          key={idx}
                          data-testid={`place-${idx}`}
                          className="p-4 rounded-lg bg-card border border-border"
                        >
                          <h3 className="font-medium">{place.name}</h3>
                          <p className="text-sm text-muted-foreground">{place.displayName}</p>
                          {place.type && (
                            <span className="inline-block mt-2 px-2 py-1 rounded text-xs bg-muted">
                              {place.type}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="text-center py-20 text-muted-foreground">
                    No places found for "{query}"
                  </div>
                )}
              </div>
            )}

            {['image', 'video', 'news', 'pdf'].includes(activeType) && (
              <div className={cn('space-y-6 transition-opacity', searchFetching && 'opacity-60')}>
                <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                  <span>
                    About {searchData?.total.toLocaleString() || 0} results (
                    {searchData?.tookMs || 0}ms)
                  </span>
                </div>

                {results.length > 0 ? (
                  <div className="space-y-8">
                    {results.map((result, idx) => (
                      <div key={result.id}>
                        <SearchResult result={result} index={idx} />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-20 text-muted-foreground">
                    No {activeType} results found for "{query}"
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
