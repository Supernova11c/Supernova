import { Header } from '@/components/Header';
import { Shield, Eye, Database, Lock } from 'lucide-react';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-12 max-w-3xl">
        <div className="space-y-12">
          <div className="text-center space-y-4">
            <div className="flex justify-center mb-4">
              <div className="flex items-center justify-center w-16 h-16 rounded-full bg-primary/10">
                <Shield className="w-8 h-8 text-primary" />
              </div>
            </div>
            <h1 className="font-display font-bold text-4xl">Privacy First</h1>
            <p className="text-xl text-muted-foreground">
              Your searches are private. We don't track you, profile you, or sell your data.
            </p>
          </div>

          <div className="space-y-8">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500/10">
                  <Eye className="w-5 h-5 text-green-500" />
                </div>
                <h2 className="font-display font-semibold text-2xl">What we don't collect</h2>
              </div>
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <ul>
                  <li>
                    <strong>No IP address retention:</strong> We don't store your IP address or use
                    it to identify you.
                  </li>
                  <li>
                    <strong>No search history:</strong> Your search queries are not associated with
                    any identifier that could link them back to you.
                  </li>
                  <li>
                    <strong>No user profiles:</strong> We don't build behavioral profiles or track
                    you across sessions.
                  </li>
                  <li>
                    <strong>No advertising cookies:</strong> We don't use cookies for ads or
                    tracking purposes.
                  </li>
                  <li>
                    <strong>No third-party trackers:</strong> No analytics scripts, no social media
                    pixels, no hidden surveillance.
                  </li>
                </ul>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-blue-500/10">
                  <Database className="w-5 h-5 text-blue-500" />
                </div>
                <h2 className="font-display font-semibold text-2xl">What we do collect</h2>
              </div>
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <p>
                  We collect minimal, anonymized data to improve search quality and prevent abuse:
                </p>
                <ul>
                  <li>
                    <strong>Aggregated search queries:</strong> We analyze popular search terms in
                    aggregate (not linked to individuals) to improve relevance.
                  </li>
                  <li>
                    <strong>Technical logs:</strong> Anonymized server logs for debugging and
                    infrastructure health, retained for 7 days maximum.
                  </li>
                  <li>
                    <strong>Feedback submissions:</strong> If you voluntarily report an issue with a
                    result, we store that feedback to improve search quality.
                  </li>
                </ul>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-orange-500/10">
                  <Lock className="w-5 h-5 text-orange-500" />
                </div>
                <h2 className="font-display font-semibold text-2xl">Anonymous mode</h2>
              </div>
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <p>
                  By default, Supernova Search operates in a privacy-respecting mode. For even
                  stricter privacy:
                </p>
                <ul>
                  <li>Use a VPN or Tor to mask your network identity</li>
                  <li>Disable JavaScript for maximum privacy (search still works)</li>
                  <li>Use private/incognito browsing mode in your browser</li>
                </ul>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="font-display font-semibold text-2xl">Our commitments</h2>
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <ul>
                  <li>We will never sell your data to advertisers or third parties</li>
                  <li>We will never build shadow profiles or fingerprint your device</li>
                  <li>
                    We will be transparent about any changes to this privacy policy, with at least 30
                    days notice
                  </li>
                  <li>We will fight legal requests for user data where permissible by law</li>
                  <li>
                    We will open-source our privacy mechanisms when the codebase reaches production
                    maturity
                  </li>
                </ul>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="font-display font-semibold text-2xl">Questions?</h2>
              <p className="text-muted-foreground">
                Privacy is a right, not a privilege. If you have concerns or questions about how your
                data is handled, contact us at privacy@supernova.search (placeholder — update with
                actual contact).
              </p>
            </div>

            <div className="pt-8 border-t border-border">
              <p className="text-sm text-muted-foreground">
                Last updated: January 2025 · This policy applies to Supernova Search globally,
                including users in Nepal and beyond.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
