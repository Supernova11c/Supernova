import { Header } from '@/components/Header';
import { useGetDiscovery } from '@workspace/api-client-react';
import { Loader2, PlayCircle, ExternalLink } from 'lucide-react';
import { Link } from 'wouter';

export default function Discovery() {
  const { data, isLoading } = useGetDiscovery();

  const news = data?.news ?? [];
  const videos = data?.videos ?? [];

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold mb-2">Discovery</h1>
          <p className="text-muted-foreground">
            Fresh news and videos, pulled in real time from live RSS feeds and YouTube — not a
            fixed snapshot.
          </p>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="space-y-12">
            <section>
              <h2 className="text-xl font-display font-semibold mb-4">News</h2>
              {news.length === 0 ? (
                <p className="text-muted-foreground text-sm">
                  No news with images indexed yet — the discovery scheduler runs every 30
                  minutes.
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {news.map((item, idx) => (
                    <a
                      key={item.id}
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      data-testid={`discovery-news-${idx}`}
                      className="group rounded-xl border border-border bg-card overflow-hidden hover:border-primary transition-colors flex flex-col"
                    >
                      {item.thumbnailUrl && (
                        <div className="aspect-video overflow-hidden bg-muted">
                          <img
                            src={item.thumbnailUrl}
                            alt={item.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                      )}
                      <div className="p-4 flex-1 flex flex-col">
                        <span className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                          {item.domain}
                          <ExternalLink className="w-3 h-3" />
                        </span>
                        <h3 className="font-medium leading-snug line-clamp-2 mb-1">
                          {item.title}
                        </h3>
                        <p className="text-sm text-muted-foreground line-clamp-2 mt-auto">
                          {item.description}
                        </p>
                      </div>
                    </a>
                  ))}
                </div>
              )}
            </section>

            <section>
              <h2 className="text-xl font-display font-semibold mb-4">Videos</h2>
              {videos.length === 0 ? (
                <p className="text-muted-foreground text-sm">
                  No videos indexed yet — the YouTube discovery job runs hourly.
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                  {videos.map((item, idx) => (
                    <a
                      key={item.id}
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      data-testid={`discovery-video-${idx}`}
                      className="group rounded-xl border border-border bg-card overflow-hidden hover:border-primary transition-colors flex flex-col"
                    >
                      <div className="relative aspect-video overflow-hidden bg-muted">
                        {item.thumbnailUrl && (
                          <img
                            src={item.thumbnailUrl}
                            alt={item.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        )}
                        <div className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/10 transition-colors">
                          <PlayCircle className="w-12 h-12 text-white drop-shadow-lg" />
                        </div>
                      </div>
                      <div className="p-4 flex-1 flex flex-col">
                        <span className="text-xs text-muted-foreground mb-1">YouTube</span>
                        <h3 className="font-medium leading-snug line-clamp-2">{item.title}</h3>
                      </div>
                    </a>
                  ))}
                </div>
              )}
            </section>
          </div>
        )}

        <div className="mt-12 text-center">
          <Link href="/search?q=&type=news" className="text-sm text-primary hover:underline">
            Search all news and videos instead →
          </Link>
        </div>
      </div>
    </div>
  );
}
