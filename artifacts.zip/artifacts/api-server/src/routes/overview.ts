import { Router, type IRouter } from "express";
import { sql, and, eq, desc } from "drizzle-orm";
import { db, pagesTable } from "@workspace/db";
import { GetAiOverviewQueryParams, GetAiOverviewResponse } from "@workspace/api-zod";
import { generateAiOverview } from "../lib/aiOverview";

const router: IRouter = Router();

router.get("/overview", async (req, res) => {
  const { q } = GetAiOverviewQueryParams.parse(req.query);

  const tsQuery = sql`plainto_tsquery('english', ${q})`;
  const tsVector = sql`to_tsvector('english', coalesce(${pagesTable.title}, '') || ' ' || coalesce(${pagesTable.description}, '') || ' ' || coalesce(${pagesTable.content}, ''))`;

  const topPages = await db
    .select({
      url: pagesTable.url,
      title: pagesTable.title,
      description: pagesTable.description,
      content: pagesTable.content,
    })
    .from(pagesTable)
    .where(and(eq(pagesTable.status, "indexed"), sql`${tsVector} @@ ${tsQuery}`))
    .orderBy(desc(sql`ts_rank(${tsVector}, ${tsQuery})`))
    .limit(5);

  const sources = topPages.map((p, i) => ({
    index: i + 1,
    url: p.url,
    title: p.title,
    snippet: (p.description || p.content).slice(0, 500),
  }));

  const overview = await generateAiOverview(q, sources);

  res.json(
    GetAiOverviewResponse.parse({
      query: q,
      ...overview,
    }),
  );
});

export default router;
