import { Router, type IRouter } from "express";
import { and, desc, eq, isNotNull } from "drizzle-orm";
import { db, pagesTable } from "@workspace/db";
import { GetDiscoveryResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/discovery", async (_req, res) => {
  const newsRows = await db
    .select()
    .from(pagesTable)
    .where(
      and(
        eq(pagesTable.status, "indexed"),
        eq(pagesTable.contentType, "news"),
        isNotNull(pagesTable.thumbnailUrl),
      ),
    )
    .orderBy(desc(pagesTable.crawledAt))
    .limit(24);

  const videoRows = await db
    .select()
    .from(pagesTable)
    .where(and(eq(pagesTable.status, "indexed"), eq(pagesTable.contentType, "video")))
    .orderBy(desc(pagesTable.crawledAt))
    .limit(24);

  const toResult = (p: typeof pagesTable.$inferSelect) => ({
    id: p.id,
    url: p.url,
    domain: p.domain,
    title: p.title,
    description: p.description,
    snippet: p.description.slice(0, 220),
    contentType: p.contentType as "web" | "image" | "video" | "news" | "pdf" | "map",
    thumbnailUrl: p.thumbnailUrl,
    publishedAt: p.publishedAt,
    language: p.language,
    tags: p.tags,
    categories: p.categories,
    country: p.country,
    lat: p.lat,
    lon: p.lon,
    trustScore: p.trustScore,
    isTrusted: p.isTrusted,
    score: p.trustScore,
  });

  res.json(
    GetDiscoveryResponse.parse({
      news: newsRows.map(toResult),
      videos: videoRows.map(toResult),
    }),
  );
});

export default router;
