import { Router, type IRouter } from "express";
import { sql, desc } from "drizzle-orm";
import { db, searchEventsTable, pagesTable } from "@workspace/db";
import { SuggestQueryParams, SuggestResponse, GetTrendingResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/suggest", async (req, res) => {
  const { q } = SuggestQueryParams.parse(req.query);
  const like = `${q.toLowerCase()}%`;

  const fromHistory = await db
    .selectDistinct({ query: searchEventsTable.query })
    .from(searchEventsTable)
    .where(sql`lower(${searchEventsTable.query}) like ${like}`)
    .limit(5);

  const fromTitles = await db
    .select({ title: pagesTable.title })
    .from(pagesTable)
    .where(sql`lower(${pagesTable.title}) like ${"%" + q.toLowerCase() + "%"}`)
    .limit(5);

  const suggestions = Array.from(
    new Set([
      ...fromHistory.map((r) => r.query),
      ...fromTitles.map((r) => r.title).filter(Boolean),
    ]),
  ).slice(0, 8);

  res.json(SuggestResponse.parse({ suggestions }));
});

router.get("/trending", async (_req, res) => {
  const recent = await db
    .select({ query: searchEventsTable.query, count: sql<number>`count(*)` })
    .from(searchEventsTable)
    .where(sql`${searchEventsTable.createdAt} > now() - interval '2 days'`)
    .groupBy(searchEventsTable.query)
    .orderBy(desc(sql`count(*)`))
    .limit(10);

  const fallback = [
    "Nepal news today",
    "Kathmandu weather",
    "Nepal tourism",
    "Everest base camp trek",
    "Nepal general elections",
  ];

  const queries = recent.length
    ? recent.map((r) => r.query)
    : fallback;

  res.json(GetTrendingResponse.parse({ queries }));
});

export default router;
