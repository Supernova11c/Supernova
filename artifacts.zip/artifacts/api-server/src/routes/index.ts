import { Router, type IRouter } from "express";
import healthRouter from "./health";
import searchRouter from "./search";
import discoveryRouter from "./discovery";
import suggestRouter from "./suggest";
import geoRouter from "./geo";
import overviewRouter from "./overview";
import feedbackRouter from "./feedback";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(searchRouter);
router.use(discoveryRouter);
router.use(suggestRouter);
router.use(geoRouter);
router.use(overviewRouter);
router.use(feedbackRouter);
router.use(adminRouter);

export default router;
