import { Router, type IRouter } from "express";
import { GeoSearchQueryParams, GeoSearchResponse } from "@workspace/api-zod";
import { geoSearch } from "../lib/geo";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.get("/geo/search", async (req, res) => {
  const { q } = GeoSearchQueryParams.parse(req.query);
  try {
    const places = await geoSearch(q);
    res.json(GeoSearchResponse.parse({ places }));
  } catch (err) {
    logger.error({ err, q }, "Geo search failed");
    res.json(GeoSearchResponse.parse({ places: [] }));
  }
});

export default router;
