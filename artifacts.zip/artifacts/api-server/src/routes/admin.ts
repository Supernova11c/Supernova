import { Router, type IRouter } from "express";
import { sql, eq } from "drizzle-orm";
import {
  db,
  pagesTable,
  errorLogsTable,
  feedbackTable,
  spamReportsTable,
} from "@workspace/db";
import {
  GetAdminStatsResponse,
  GetAdminHealthResponse,
  ListCrawlJobsQueryParams,
  ListCrawlJobsResponse,
  SubmitCrawlUrlBody,
  SubmitCrawlUrlResponse,
  ReindexCrawlJobParams,
  ReindexCrawlJobResponse,
  ReindexAllResponse,
  ListErrorLogsResponse,
  ListFeedbackResponse,
  UpdateFeedbackStatusParams,
  UpdateFeedbackStatusBody,
  UpdateFeedbackStatusResponse,
  ListSpamReportsResponse,
  UpdateSpamReportStatusParams,
  UpdateSpamReportStatusBody,
  UpdateSpamReportStatusResponse,
} from "@workspace/api-zod";
import { requireAdmin } from "../lib/adminAuth";
import { crawlUrl, reindexAll } from "../lib/crawler";
import { extractDomain, stripTrackingParams, isValidHttpUrl } from "../lib/urlUtils";
import { pool } from "@workspace/db";

const router: IRouter = Router();

router.use(requireAdmin);

router.get("/admin/stats", async (_req, res) => {
  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);

  const [totals] = await db
    .select({
      totalPages: sql<number>`count(*) filter (where ${pagesTable.status} = 'indexed')`,
      totalDomains: sql<number>`count(distinct ${pagesTable.domain}) filter (where ${pagesTable.status} = 'indexed')`,
      queueSize: sql<number>`count(*) filter (where ${pagesTable.status} = 'queued')`,
      lastCrawlAt: sql<Date | null>`max(${pagesTable.crawledAt})`,
      indexedToday: sql<number>`count(*) filter (where ${pagesTable.status} = 'indexed' and ${pagesTable.crawledAt} >= ${startOfDay})`,
      failedToday: sql<number>`count(*) filter (where ${pagesTable.status} = 'failed' and ${pagesTable.crawledAt} >= ${startOfDay})`,
    })
    .from(pagesTable);

  const byContentTypeRows = await db
    .select({ type: pagesTable.contentType, count: sql<number>`count(*)` })
    .from(pagesTable)
    .where(eq(pagesTable.status, "indexed"))
    .groupBy(pagesTable.contentType);

  const byLanguageRows = await db
    .select({ lang: pagesTable.language, count: sql<number>`count(*)` })
    .from(pagesTable)
    .where(eq(pagesTable.status, "indexed"))
    .groupBy(pagesTable.language);

  const [openFeedbackRow] = await db
    .select({ count: sql<number>`count(*)` })
    .from(feedbackTable)
    .where(eq(feedbackTable.status, "open"));

  const [openSpamRow] = await db
    .select({ count: sql<number>`count(*)` })
    .from(spamReportsTable)
    .where(eq(spamReportsTable.status, "open"));

  res.json(
    GetAdminStatsResponse.parse({
      crawl: {
        totalPages: Number(totals?.totalPages ?? 0),
        totalDomains: Number(totals?.totalDomains ?? 0),
        queueSize: Number(totals?.queueSize ?? 0),
        lastCrawlAt: totals?.lastCrawlAt ?? null,
        lastFullIndexAt: totals?.lastCrawlAt ?? null,
        indexedToday: Number(totals?.indexedToday ?? 0),
        failedToday: Number(totals?.failedToday ?? 0),
      },
      index: {
        totalDocuments: Number(totals?.totalPages ?? 0),
        byContentType: Object.fromEntries(
          byContentTypeRows.map((r) => [r.type, Number(r.count)]),
        ),
        byLanguage: Object.fromEntries(
          byLanguageRows.map((r) => [r.lang, Number(r.count)]),
        ),
      },
      openFeedback: Number(openFeedbackRow?.count ?? 0),
      openSpamReports: Number(openSpamRow?.count ?? 0),
    }),
  );
});

router.get("/admin/health", async (_req, res) => {
  let database: "ok" | "degraded" | "down" = "ok";
  try {
    await pool.query("select 1");
  } catch {
    database = "down";
  }

  const [lastCrawlRow] = await db
    .select({ lastCrawlAt: sql<Date | null>`max(${pagesTable.crawledAt})` })
    .from(pagesTable);

  const lastCrawlAt = lastCrawlRow?.lastCrawlAt ?? null;
  const crawler: "ok" | "degraded" | "down" = lastCrawlAt
    ? Date.now() - new Date(lastCrawlAt).getTime() < 1000 * 60 * 60 * 48
      ? "ok"
      : "degraded"
    : "degraded";

  // Pollinations.ai is a free, unofficial third-party service with no uptime
  // guarantee, so we report it as best-effort rather than probing live.
  const aiOverview: "ok" | "degraded" | "down" = "ok";

  res.json(GetAdminHealthResponse.parse({ database, crawler, aiOverview, lastCrawlAt }));
});

router.get("/admin/crawl-jobs", async (req, res) => {
  const { status } = ListCrawlJobsQueryParams.parse(req.query);
  const rows = await db
    .select()
    .from(pagesTable)
    .where(status ? eq(pagesTable.status, status) : undefined)
    .orderBy(sql`${pagesTable.discoveredAt} desc`)
    .limit(200);

  res.json(ListCrawlJobsResponse.parse(rows));
});

router.post("/admin/crawl-jobs", async (req, res) => {
  const { url: rawUrl } = SubmitCrawlUrlBody.parse(req.body);
  if (!isValidHttpUrl(rawUrl)) {
    res.status(400).json({ error: "invalid_url", message: "Provide a valid http(s) URL." });
    return;
  }
  const url = stripTrackingParams(rawUrl);
  const domain = extractDomain(url);

  const [queued] = await db
    .insert(pagesTable)
    .values({ url, domain, status: "queued" })
    .onConflictDoUpdate({ target: pagesTable.url, set: { status: "queued", error: null } })
    .returning();

  // Crawl immediately so the admin gets fast feedback instead of waiting for
  // the next scheduled queue sweep.
  const crawled = await crawlUrl(url);

  res.status(201).json(SubmitCrawlUrlResponse.parse(crawled ?? queued));
});

router.post("/admin/crawl-jobs/:id/reindex", async (req, res) => {
  const { id } = ReindexCrawlJobParams.parse(req.params);
  const [job] = await db.select().from(pagesTable).where(eq(pagesTable.id, id));
  if (!job) {
    res.status(404).json({ error: "not_found", message: "Crawl job not found." });
    return;
  }
  const crawled = await crawlUrl(job.url);
  res.json(ReindexCrawlJobResponse.parse(crawled ?? job));
});

router.post("/admin/reindex-all", async (_req, res) => {
  const queued = await reindexAll();
  res.json(ReindexAllResponse.parse({ queued }));
});

router.get("/admin/error-logs", async (_req, res) => {
  const rows = await db
    .select()
    .from(errorLogsTable)
    .orderBy(sql`${errorLogsTable.createdAt} desc`)
    .limit(100);
  res.json(ListErrorLogsResponse.parse(rows));
});

router.get("/admin/feedback", async (_req, res) => {
  const rows = await db
    .select()
    .from(feedbackTable)
    .orderBy(sql`${feedbackTable.createdAt} desc`)
    .limit(200);
  res.json(ListFeedbackResponse.parse(rows));
});

router.patch("/admin/feedback/:id", async (req, res) => {
  const { id } = UpdateFeedbackStatusParams.parse(req.params);
  const { status } = UpdateFeedbackStatusBody.parse(req.body);
  const [row] = await db
    .update(feedbackTable)
    .set({ status })
    .where(eq(feedbackTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "not_found", message: "Feedback entry not found." });
    return;
  }
  res.json(UpdateFeedbackStatusResponse.parse(row));
});

router.get("/admin/spam-reports", async (_req, res) => {
  const rows = await db
    .select()
    .from(spamReportsTable)
    .orderBy(sql`${spamReportsTable.createdAt} desc`)
    .limit(200);
  res.json(ListSpamReportsResponse.parse(rows));
});

router.patch("/admin/spam-reports/:id", async (req, res) => {
  const { id } = UpdateSpamReportStatusParams.parse(req.params);
  const { status } = UpdateSpamReportStatusBody.parse(req.body);
  const [row] = await db
    .update(spamReportsTable)
    .set({ status })
    .where(eq(spamReportsTable.id, id))
    .returning();
  if (!row) {
    res.status(404).json({ error: "not_found", message: "Spam report not found." });
    return;
  }

  if (status === "removed") {
    await db.update(pagesTable).set({ status: "blocked" }).where(eq(pagesTable.url, row.url));
  }

  res.json(UpdateSpamReportStatusResponse.parse(row));
});

export default router;
