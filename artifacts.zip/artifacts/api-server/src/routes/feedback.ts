import { Router, type IRouter } from "express";
import { db, feedbackTable, spamReportsTable } from "@workspace/db";
import {
  SubmitFeedbackBody,
  SubmitFeedbackResponse,
  SubmitSpamReportBody,
  SubmitSpamReportResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/feedback", async (req, res) => {
  const body = SubmitFeedbackBody.parse(req.body);
  const [row] = await db
    .insert(feedbackTable)
    .values({
      query: body.query,
      url: body.url ?? null,
      type: body.type,
      comment: body.comment ?? null,
    })
    .returning();

  res.status(201).json(SubmitFeedbackResponse.parse(row));
});

router.post("/spam-reports", async (req, res) => {
  const body = SubmitSpamReportBody.parse(req.body);
  const [row] = await db
    .insert(spamReportsTable)
    .values({ url: body.url, reason: body.reason })
    .returning();

  res.status(201).json(SubmitSpamReportResponse.parse(row));
});

export default router;
