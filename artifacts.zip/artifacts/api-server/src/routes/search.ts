import { Router, type IRouter } from "express";
import { sql, eq, and, desc } from "drizzle-orm";
import { db, pagesTable, searchEventsTable } from "@workspace/db";
import { SearchQueryParams, SearchResponse } from "@workspace/api-zod";
import { scorePage } from "../lib/ranking";
import { logger } from "../lib/logger";
import { parseQuery } from "../lib/queryParser";
import { resolveDirectNav } from "../lib/siteDirectory";
import { trigramAvailable } from "../lib/dbExtensions";

const router: IRouter = Router();

const CONTENT_TYPES = ["web", "image", "video", "news", "pdf", "map"] as const;

interface Candidate {
  id: number;
  url: string;
  domain: string;
  title: string;
  description: string;
  content: string;
  contentType: string;
  thumbnailUrl: string | null;
  publishedAt: Date | null;
  language: string;
  tags: string[];
  categories: string[];
  country: string | null;
  lat: number | null;
  lon: number | null;
  trustScore: number;
  isTrusted: boolean;
  crawledAt: Date | null;
  relevance: number;
}

router.get("/search", async (req, res) => {
  const started = Date.now();
  const params = SearchQueryParams.parse(req.query);
  const { q, type, page, perPage, lang, country } = params;

  void db.insert(searchEventsTable).values({ query: q }).catch((err) => {
    logger.warn({ err }, "Failed to log search event");
  });

  const parsed = parseQuery(q);
  const baseConditions = [eq(pagesTable.status, "indexed")];
  if (type) baseConditions.push(eq(pagesTable.contentType, type));

  // Tier 1: strict AND match on the user's positive terms (highest
  // precision). Tier 2: OR match across positive terms (recall fallback
  // when the exact combination doesn't co-occur in any document — this is
  // what stops "0 results" for multi-concept queries). Tier 3: trigram
  // fuzzy similarity on title/description (best-effort typo/paraphrase
  // tolerance; only runs if pg_trgm is available on this database).
  let candidates = await runTier(parsed.positiveQuery, "and", baseConditions);
  let tier = "and";
  if (candidates.length === 0 && parsed.positiveTerms.length > 1) {
    candidates = await runTier(parsed.positiveTerms.join(" | "), "or", baseConditions);
    tier = "or";
  }
  if (candidates.length === 0 && (await trigramAvailable())) {
    candidates = await runTrigramTier(parsed.positiveQuery, baseConditions);
    tier = "trigram";
  }

  const negativeTermSet = new Set(parsed.negativeTerms);
  const scored = candidates
    .map((page) => {
      const negatedTermHits = negativeTermSet.size
        ? countTermHits(`${page.title} ${page.description} ${page.content}`, negativeTermSet)
        : 0;
      return {
        page,
        score: scorePage(page, { lang, country, negatedTermHits }),
      };
    })
    .sort((a, b) => b.score - a.score);

  const total = scored.length;
  const start = (page - 1) * perPage;
  const pageItems = scored.slice(start, start + perPage);

  const results = pageItems.map(({ page: p, score }) => ({
    id: p.id,
    url: p.url,
    domain: p.domain,
    title: p.title,
    description: p.description,
    snippet: buildSnippet(p.content, q, p.description),
    contentType: p.contentType as (typeof CONTENT_TYPES)[number],
    thumbnailUrl: p.thumbnailUrl,
    publishedAt: p.publishedAt,
    language: p.language,
    tags: p.tags,
    categories: p.categories,
    country: p.country,
    lat: p.lat,
    lon: p.lon,
    trustScore: p.trustScore,
    isTrusted: p.isTrusted,
    score,
    isDirectNav: false,
  }));

  // Direct navigation: only relevant for the default "web" experience
  // (no explicit non-web type filter) and only on the first page.
  if ((!type || type === "web") && page === 1) {
    const directNav = resolveDirectNav(q);
    if (directNav) {
      results.unshift({
        id: -1,
        url: directNav.url,
        domain: directNav.domain,
        title: directNav.title,
        description: directNav.description,
        snippet: directNav.description,
        contentType: "web",
        thumbnailUrl: null,
        publishedAt: null,
        language: lang ?? "en",
        tags: [],
        categories: [],
        country: null,
        lat: null,
        lon: null,
        trustScore: 1,
        isTrusted: true,
        score: 999,
        isDirectNav: true,
      });
    }
  }

  const relatedSearches = buildRelatedSearches(q, candidates.map((c) => c.title));

  const data = SearchResponse.parse({
    query: q,
    tookMs: Date.now() - started,
    total,
    page,
    perPage,
    results,
    relatedSearches,
  });

  logger.info({ q, tier, resultCount: total }, "search served");
  res.json(data);
});

async function runTier(
  tsQueryInput: string,
  mode: "and" | "or",
  baseConditions: unknown[],
): Promise<Candidate[]> {
  if (!tsQueryInput.trim()) return [];

  const tsQuery =
    mode === "and"
      ? sql`plainto_tsquery('english', ${tsQueryInput})`
      : sql`to_tsquery('english', ${tsQueryInput
          .split(/\s+/)
          .filter(Boolean)
          .map((t) => t.replace(/[^a-z0-9]/gi, ""))
          .filter(Boolean)
          .join(" | ")})`;

  const tsVector = sql`to_tsvector('english', coalesce(${pagesTable.title}, '') || ' ' || coalesce(${pagesTable.description}, '') || ' ' || coalesce(${pagesTable.content}, ''))`;

  const conditions = [...(baseConditions as never[]), sql`${tsVector} @@ ${tsQuery}`];

  const rows = await db
    .select({
      id: pagesTable.id,
      url: pagesTable.url,
      domain: pagesTable.domain,
      title: pagesTable.title,
      description: pagesTable.description,
      content: pagesTable.content,
      contentType: pagesTable.contentType,
      thumbnailUrl: pagesTable.thumbnailUrl,
      publishedAt: pagesTable.publishedAt,
      language: pagesTable.language,
      tags: pagesTable.tags,
      categories: pagesTable.categories,
      country: pagesTable.country,
      lat: pagesTable.lat,
      lon: pagesTable.lon,
      trustScore: pagesTable.trustScore,
      isTrusted: pagesTable.isTrusted,
      crawledAt: pagesTable.crawledAt,
      relevance: sql<number>`ts_rank(${tsVector}, ${tsQuery})`,
    })
    .from(pagesTable)
    .where(and(...conditions))
    .orderBy(desc(sql`ts_rank(${tsVector}, ${tsQuery})`))
    .limit(200);

  return rows as Candidate[];
}

async function runTrigramTier(query: string, baseConditions: unknown[]): Promise<Candidate[]> {
  if (!query.trim()) return [];
  const similarity = sql<number>`greatest(similarity(${pagesTable.title}, ${query}), similarity(${pagesTable.description}, ${query}))`;
  const conditions = [...(baseConditions as never[]), sql`${similarity} > 0.15`];

  const rows = await db
    .select({
      id: pagesTable.id,
      url: pagesTable.url,
      domain: pagesTable.domain,
      title: pagesTable.title,
      description: pagesTable.description,
      content: pagesTable.content,
      contentType: pagesTable.contentType,
      thumbnailUrl: pagesTable.thumbnailUrl,
      publishedAt: pagesTable.publishedAt,
      language: pagesTable.language,
      tags: pagesTable.tags,
      categories: pagesTable.categories,
      country: pagesTable.country,
      lat: pagesTable.lat,
      lon: pagesTable.lon,
      trustScore: pagesTable.trustScore,
      isTrusted: pagesTable.isTrusted,
      crawledAt: pagesTable.crawledAt,
      relevance: similarity,
    })
    .from(pagesTable)
    .where(and(...conditions))
    .orderBy(desc(similarity))
    .limit(100);

  return rows as Candidate[];
}

function countTermHits(text: string, terms: Set<string>): number {
  const lower = text.toLowerCase();
  let hits = 0;
  for (const term of terms) {
    if (lower.includes(term)) hits += 1;
  }
  return hits;
}

function buildSnippet(content: string, query: string, fallback: string): string {
  if (!content) return fallback.slice(0, 220);
  const lower = content.toLowerCase();
  const idx = lower.indexOf(query.toLowerCase().split(" ")[0] ?? "");
  if (idx === -1) return content.slice(0, 220);
  const start = Math.max(0, idx - 80);
  const end = Math.min(content.length, idx + 160);
  return `${start > 0 ? "…" : ""}${content.slice(start, end)}${end < content.length ? "…" : ""}`;
}

function buildRelatedSearches(query: string, titles: string[]): string[] {
  const words = new Set<string>();
  for (const title of titles.slice(0, 10)) {
    for (const word of title.split(/\s+/)) {
      const cleaned = word.replace(/[^a-zA-Z0-9]/g, "");
      if (cleaned.length > 4 && !query.toLowerCase().includes(cleaned.toLowerCase())) {
        words.add(cleaned);
      }
      if (words.size >= 5) break;
    }
    if (words.size >= 5) break;
  }
  return Array.from(words)
    .slice(0, 5)
    .map((w) => `${query} ${w}`);
}

export default router;
