/**
 * One-off seed script: crawls a curated set of real, publicly accessible
 * pages so the index isn't empty on first load. Run with:
 *   pnpm --filter @workspace/api-server run seed
 */
import { crawlUrl, processQueuedJobs } from "../lib/crawler";
import { discoverFromFeeds } from "../lib/rss";
import { FEED_SOURCES } from "../lib/feedSources";
import { discoverFromYoutubeChannels } from "../lib/youtube";
import { YOUTUBE_CHANNELS } from "../lib/youtubeChannels";
import { logger } from "../lib/logger";
import { pool } from "@workspace/db";

interface SeedEntry {
  url: string;
  contentTypeHint?: "web" | "news";
  categories?: string[];
  country?: string;
}

const SEED_URLS: SeedEntry[] = [
  // Nepal — news & reference
  { url: "https://en.wikipedia.org/wiki/Nepal", categories: ["geography", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Kathmandu", categories: ["geography", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Mount_Everest", categories: ["geography", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Economy_of_Nepal", categories: ["economy", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Culture_of_Nepal", categories: ["culture", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Politics_of_Nepal", categories: ["politics", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Tourism_in_Nepal", categories: ["travel", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Geography_of_Nepal", categories: ["geography", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/History_of_Nepal", categories: ["history", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Nepali_language", categories: ["culture", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Cuisine_of_Nepal", categories: ["culture", "food"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Education_in_Nepal", categories: ["education", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Religion_in_Nepal", categories: ["culture", "reference"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Sagarmatha_National_Park", categories: ["geography", "travel"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Pokhara", categories: ["geography", "travel"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Annapurna", categories: ["geography", "travel"], country: "NP" },
  { url: "https://en.wikipedia.org/wiki/Lumbini", categories: ["geography", "travel", "culture"], country: "NP" },
  { url: "https://kathmandupost.com/", contentTypeHint: "news", categories: ["news"], country: "NP" },
  { url: "https://www.onlinekhabar.com/", contentTypeHint: "news", categories: ["news"], country: "NP" },
  { url: "https://www.nepalitimes.com/", contentTypeHint: "news", categories: ["news"], country: "NP" },
  { url: "https://thehimalayantimes.com/", contentTypeHint: "news", categories: ["news"], country: "NP" },
  { url: "https://www.worldbank.org/en/country/nepal", categories: ["economy"], country: "NP" },
  { url: "https://www.imf.org/en/Countries/NPL", categories: ["economy"], country: "NP" },
  // General reference / encyclopedic
  { url: "https://en.wikipedia.org/wiki/Artificial_intelligence", categories: ["technology", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Climate_change", categories: ["science", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Renewable_energy", categories: ["science", "reference"] },
  { url: "https://en.wikipedia.org/wiki/World_Wide_Web", categories: ["technology", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Privacy", categories: ["technology", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Internet", categories: ["technology", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Search_engine", categories: ["technology", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Machine_learning", categories: ["technology", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Quantum_computing", categories: ["science", "technology", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Space_exploration", categories: ["science", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Blockchain", categories: ["technology", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Solar_System", categories: ["science", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Human_body", categories: ["health", "reference"] },
  { url: "https://en.wikipedia.org/wiki/Nutrition", categories: ["health", "reference"] },
  { url: "https://en.wikipedia.org/wiki/World_economy", categories: ["economy", "reference"] },
  // Technical documentation (drives good "docs" search results)
  { url: "https://developer.mozilla.org/en-US/docs/Web/JavaScript", categories: ["technology", "docs"] },
  { url: "https://developer.mozilla.org/en-US/docs/Web/HTML", categories: ["technology", "docs"] },
  { url: "https://developer.mozilla.org/en-US/docs/Web/CSS", categories: ["technology", "docs"] },
  { url: "https://docs.python.org/3/tutorial/index.html", categories: ["technology", "docs"] },
  { url: "https://react.dev/learn", categories: ["technology", "docs"] },
  { url: "https://nodejs.org/en/about", categories: ["technology", "docs"] },
  { url: "https://www.typescriptlang.org/docs/", categories: ["technology", "docs"] },
  { url: "https://git-scm.com/doc", categories: ["technology", "docs"] },
  // World / global news + institutions
  { url: "https://www.bbc.com/news/world", contentTypeHint: "news", categories: ["news"] },
  { url: "https://www.who.int/", categories: ["health"] },
  { url: "https://www.un.org/en/global-issues", categories: ["politics"] },
  { url: "https://www.nature.com/", categories: ["science"] },
];

async function main() {
  logger.info({ count: SEED_URLS.length }, "Starting seed crawl");
  let ok = 0;
  let failed = 0;

  for (const entry of SEED_URLS) {
    const result = await crawlUrl(entry.url, {
      contentTypeHint: entry.contentTypeHint,
      categories: entry.categories,
      country: entry.country,
    });
    if (result?.status === "indexed") {
      ok += 1;
      logger.info({ url: entry.url }, "Seeded");
    } else {
      failed += 1;
      logger.warn({ url: entry.url, status: result?.status, error: result?.error }, "Seed failed");
    }
  }

  logger.info({ ok, failed }, "Seed crawl complete");

  logger.info("Discovering fresh articles from RSS feeds");
  const discovered = await discoverFromFeeds(FEED_SOURCES);
  logger.info({ discovered }, "Feed discovery queued URLs");

  // Crawl everything the feeds just queued, in batches.
  let remaining = discovered;
  while (remaining > 0) {
    const batch = Math.min(remaining, 10);
    await processQueuedJobs(batch);
    remaining -= batch;
  }
  logger.info("Finished crawling feed-discovered articles");

  logger.info("Discovering videos from curated YouTube channels");
  const videosIndexed = await discoverFromYoutubeChannels(YOUTUBE_CHANNELS);
  logger.info({ videosIndexed }, "YouTube discovery complete");

  await pool.end();
}

main().catch((err) => {
  logger.error({ err }, "Seed script crashed");
  process.exit(1);
});
