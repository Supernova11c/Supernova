import cron from "node-cron";
import app from "./app";
import { logger } from "./lib/logger";
import { processQueuedJobs, reindexAll } from "./lib/crawler";
import { discoverFromFeeds } from "./lib/rss";
import { FEED_SOURCES } from "./lib/feedSources";
import { discoverFromYoutubeChannels } from "./lib/youtube";
import { YOUTUBE_CHANNELS } from "./lib/youtubeChannels";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Discovery sweep: process a few newly-queued URLs (admin submissions,
  // RSS-discovered links) roughly once a minute.
  cron.schedule("*/1 * * * *", () => {
    processQueuedJobs(5).catch((err) => logger.error({ err }, "Queue sweep failed"));
  });

  // Daily full re-crawl of everything already indexed, to keep freshness
  // signals accurate.
  cron.schedule("0 6 * * *", () => {
    reindexAll().catch((err) => logger.error({ err }, "Scheduled reindex failed"));
  });

  // Every 30 minutes, discover fresh real article URLs from curated RSS
  // feeds and queue them — this is how the index keeps growing with real
  // content over time instead of staying fixed at the seed list.
  cron.schedule("*/30 * * * *", () => {
    discoverFromFeeds(FEED_SOURCES)
      .then((count) => logger.info({ count }, "Feed discovery queued new URLs"))
      .catch((err) => logger.error({ err }, "Scheduled feed discovery failed"));
  });

  // Every hour, pull fresh videos from curated YouTube channel feeds for
  // the Discovery page and video search results.
  cron.schedule("0 * * * *", () => {
    discoverFromYoutubeChannels(YOUTUBE_CHANNELS)
      .then((count) => logger.info({ count }, "YouTube discovery indexed videos"))
      .catch((err) => logger.error({ err }, "Scheduled YouTube discovery failed"));
  });
});
