import Parser from "rss-parser";
import { db, pagesTable } from "@workspace/db";
import { extractDomain, stripTrackingParams, isValidHttpUrl } from "./urlUtils";
import { logger } from "./logger";

const parser = new Parser({ timeout: 10_000 });

export interface FeedSource {
  url: string;
  country?: string;
  categories?: string[];
}

/**
 * Discovers real article links from an RSS/Atom feed and queues them for
 * crawling. This is how the index grows beyond the hand-picked seed list —
 * each run can pull in dozens of fresh, real article URLs per feed.
 */
export async function discoverFromFeed(source: FeedSource, limit = 25): Promise<number> {
  let queued = 0;
  try {
    const feed = await parser.parseURL(source.url);
    const items = (feed.items ?? []).slice(0, limit);

    for (const item of items) {
      const link = item.link;
      if (!link || !isValidHttpUrl(link)) continue;

      const url = stripTrackingParams(link);
      const domain = extractDomain(url);
      if (!domain) continue;

      await db
        .insert(pagesTable)
        .values({
          url,
          domain,
          title: item.title ?? "",
          contentType: "news",
          publishedAt: item.isoDate ? new Date(item.isoDate) : null,
          categories: source.categories ?? [],
          country: source.country ?? null,
          status: "queued",
        })
        .onConflictDoNothing({ target: pagesTable.url });

      queued += 1;
    }
  } catch (err) {
    logger.warn({ err, feed: source.url }, "RSS feed discovery failed");
  }

  return queued;
}

/**
 * Discovers real article URLs from many feeds at once. Used by the seed
 * script and can be re-run periodically (e.g. from the discovery scheduler)
 * to keep growing the index with fresh, real content — this is how
 * "more websites" actually gets added over time, rather than a fixed list.
 */
export async function discoverFromFeeds(sources: FeedSource[]): Promise<number> {
  let total = 0;
  for (const source of sources) {
    total += await discoverFromFeed(source);
  }
  return total;
}
