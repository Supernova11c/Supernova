export interface YoutubeChannelSource {
  channelId: string;
  name: string;
  categories?: string[];
}

/**
 * Real YouTube channel IDs whose public upload feeds
 * (youtube.com/feeds/videos.xml?channel_id=...) we discover from. This is
 * YouTube's own keyless RSS mechanism — no API key or scraping of
 * JS-rendered pages required, and it only surfaces videos the channel
 * owner has actually published.
 */
export const YOUTUBE_CHANNELS: YoutubeChannelSource[] = [
  { channelId: "UC16niRr50-MSBwiO3YDb3RA", name: "BBC News", categories: ["news"] },
  { channelId: "UCLA_DiR1FfKNvjuUpBHmylQ", name: "NASA", categories: ["science"] },
  { channelId: "UCsXVk37bltHxD1rDPwtNM8Q", name: "Kurzgesagt – In a Nutshell", categories: ["science", "education"] },
  { channelId: "UCHnyfMqiRRG1u-2MsSQLbXA", name: "Veritasium", categories: ["science", "education"] },
  // Verified by successful discovery run on 2026-07-15. Add more channel
  // IDs here as needed — each one must be the real /feeds/videos.xml
  // channel_id, not a @handle; verify with a manual fetch before adding,
  // since a wrong ID silently 404s (logged as a warning, not fatal).
];
