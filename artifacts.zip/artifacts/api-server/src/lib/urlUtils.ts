/**
 * Privacy helpers: strip tracking parameters before we ever store or return
 * a URL, and normalize domains for scoring/dedup.
 */
const TRACKING_PARAM_PREFIXES = ["utm_", "fbclid", "gclid", "msclkid", "mc_eid", "mc_cid", "ref_", "igshid"];
const TRACKING_PARAM_EXACT = new Set(["ref", "source", "spm", "cmpid"]);

export function stripTrackingParams(rawUrl: string): string {
  try {
    const url = new URL(rawUrl);
    const toDelete: string[] = [];
    url.searchParams.forEach((_value, key) => {
      const lower = key.toLowerCase();
      if (
        TRACKING_PARAM_PREFIXES.some((prefix) => lower.startsWith(prefix)) ||
        TRACKING_PARAM_EXACT.has(lower)
      ) {
        toDelete.push(key);
      }
    });
    toDelete.forEach((key) => url.searchParams.delete(key));
    url.hash = "";
    return url.toString();
  } catch {
    return rawUrl;
  }
}

export function extractDomain(rawUrl: string): string {
  try {
    return new URL(rawUrl).hostname.toLowerCase();
  } catch {
    return "";
  }
}

export function isValidHttpUrl(rawUrl: string): boolean {
  try {
    const url = new URL(rawUrl);
    return url.protocol === "http:" || url.protocol === "https:";
  } catch {
    return false;
  }
}
