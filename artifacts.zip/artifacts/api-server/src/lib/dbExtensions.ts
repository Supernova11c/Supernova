import { pool } from "@workspace/db";
import { logger } from "./logger";

let cached: boolean | null = null;
let vectorCached: boolean | null = null;

/**
 * Best-effort enablement check for the pg_trgm extension, used as the
 * fuzzy/"semantic-ish" fallback tier when strict and OR'd keyword search
 * both return nothing. Some managed Postgres instances restrict
 * CREATE EXTENSION; if it's unavailable we simply skip that tier rather
 * than failing the request.
 */
export async function trigramAvailable(): Promise<boolean> {
  if (cached !== null) return cached;
  try {
    await pool.query("CREATE EXTENSION IF NOT EXISTS pg_trgm");
    cached = true;
  } catch (err) {
    logger.warn({ err }, "pg_trgm extension unavailable; skipping fuzzy search tier");
    cached = false;
  }
  return cached;
}

/**
 * Best-effort enablement check for pgvector, plus the HNSW ANN index the
 * semantic-search tier relies on. Same fail-soft contract as
 * `trigramAvailable`: if this managed Postgres instance can't create the
 * extension (or the index build fails for any reason), hybrid search
 * degrades to lexical-only rather than erroring the request.
 */
export async function pgvectorAvailable(): Promise<boolean> {
  if (vectorCached !== null) return vectorCached;
  try {
    await pool.query("CREATE EXTENSION IF NOT EXISTS vector");
    // cosine distance (`<=>`) is what we use in the semantic tier query, so
    // the index must use vector_cosine_ops to actually be used by the
    // planner for that operator.
    await pool.query(
      "CREATE INDEX IF NOT EXISTS pages_embedding_hnsw_idx ON pages USING hnsw (embedding vector_cosine_ops)",
    );
    vectorCached = true;
  } catch (err) {
    logger.warn({ err }, "pgvector unavailable; skipping semantic search tier");
    vectorCached = false;
  }
  return vectorCached;
}
