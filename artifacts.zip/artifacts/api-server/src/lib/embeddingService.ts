import { logger } from "./logger";

// Lazily imported — @huggingface/transformers pulls in onnxruntime-node,
// which is heavy to load. We only pay that cost the first time an
// embedding is actually requested.
type FeatureExtractionPipeline = (
  text: string,
  options: { pooling: "mean"; normalize: true },
) => Promise<{ data: Float32Array | number[] }>;

const MODEL_ID = "Xenova/all-MiniLM-L6-v2";
export const EMBEDDING_DIMENSIONS = 384;
const EMBED_TIMEOUT_MS = 8_000;

let pipelinePromise: Promise<FeatureExtractionPipeline> | null = null;
let modelLoadFailed = false;

async function getPipeline(): Promise<FeatureExtractionPipeline> {
  if (modelLoadFailed) {
    throw new Error("Embedding model previously failed to load");
  }
  if (!pipelinePromise) {
    pipelinePromise = (async () => {
      const { pipeline } = await import("@huggingface/transformers");
      logger.info({ model: MODEL_ID }, "Loading local embedding model");
      const extractor = await pipeline("feature-extraction", MODEL_ID, {
        dtype: "fp32",
      });
      logger.info({ model: MODEL_ID }, "Embedding model ready");
      return extractor as unknown as FeatureExtractionPipeline;
    })().catch((err) => {
      modelLoadFailed = true;
      pipelinePromise = null;
      logger.error({ err }, "Failed to load local embedding model");
      throw err;
    });
  }
  return pipelinePromise;
}

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms}ms`)), ms);
    promise.then(
      (v) => {
        clearTimeout(timer);
        resolve(v);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      },
    );
  });
}

/**
 * Embeds a single piece of text into a 384-dim vector using a local
 * ONNX model (Xenova/all-MiniLM-L6-v2, via @huggingface/transformers) — no
 * external embedding API or network call per request, only a one-time
 * model download on first use (cached under the OS temp/cache dir
 * afterward).
 *
 * Returns `null` (never throws) on any failure — model load error,
 * inference error, or timeout — so callers can fall back to lexical-only
 * search/indexing without interrupting the request or the crawl.
 */
export async function embedText(text: string): Promise<number[] | null> {
  const cleaned = text.replace(/\s+/g, " ").trim().slice(0, 2000);
  if (!cleaned) return null;

  try {
    const extractor = await withTimeout(getPipeline(), EMBED_TIMEOUT_MS, "Embedding model load");
    const output = await withTimeout(
      extractor(cleaned, { pooling: "mean", normalize: true }),
      EMBED_TIMEOUT_MS,
      "Embedding inference",
    );
    return Array.from(output.data as ArrayLike<number>);
  } catch (err) {
    logger.warn({ err }, "Embedding generation failed; continuing without a vector");
    return null;
  }
}

/** Formats a JS number array as a pgvector text literal for raw SQL, e.g. `[0.1,0.2,...]`. */
export function toVectorLiteral(vec: number[]): string {
  return `[${vec.join(",")}]`;
}
