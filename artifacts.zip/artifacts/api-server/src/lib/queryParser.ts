/**
 * Turns a free-text query into a structured intent: positive terms to
 * search for, and negated terms the user explicitly wants to avoid (e.g.
 * "movies where the villain wins but does not die" -> negate "die").
 *
 * We do NOT hard-exclude documents containing negated terms — a document
 * that's overwhelmingly relevant may still legitimately mention the word
 * once. Instead we hand the negated terms back to the caller so they can
 * apply a down-ranking penalty, keeping recall high (see ranking.ts).
 */
const STOPWORDS = new Set([
  "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
  "to", "of", "in", "on", "at", "for", "with", "by", "and", "or", "but",
  "that", "this", "these", "those", "it", "its", "as", "if", "than", "then",
  "so", "such", "into", "about", "up", "down", "out", "over", "under",
  "again", "further", "once", "here", "there", "when", "where", "why",
  "how", "all", "any", "both", "each", "few", "more", "most", "other",
  "some", "own", "same", "too", "very", "can", "will", "just", "should",
  "now", "who", "whom", "which", "what",
]);

const NEGATION_CUES = ["not", "without", "no", "never"];
const CLAUSE_BREAKS = new Set([
  "and", "but", "or", "who", "which", "that", "where", "when", "while", "so",
]);

export interface ParsedQuery {
  /** Original raw query, unmodified. */
  raw: string;
  /** Terms to search for positively (stopwords removed). */
  positiveTerms: string[];
  /** Terms the user wants to avoid — used for down-ranking, not exclusion. */
  negativeTerms: string[];
  /** Positive terms re-joined into a query string, for tsquery input. */
  positiveQuery: string;
}

export function parseQuery(raw: string): ParsedQuery {
  const tokens = raw
    .toLowerCase()
    .replace(/[^a-z0-9\s']/g, " ")
    .split(/\s+/)
    .filter(Boolean);

  const negativeTerms = new Set<string>();
  const negatedIndices = new Set<number>();

  for (let i = 0; i < tokens.length; i++) {
    const token = tokens[i];
    if (!NEGATION_CUES.includes(token ?? "")) continue;

    negatedIndices.add(i);
    // Collect the run of following tokens as negated, stopping at a clause
    // break (and/but/or/...) or another negation cue.
    for (let j = i + 1; j < tokens.length; j++) {
      const next = tokens[j];
      if (!next || CLAUSE_BREAKS.has(next) || NEGATION_CUES.includes(next)) break;
      negatedIndices.add(j);
      if (!STOPWORDS.has(next)) negativeTerms.add(next);
    }
  }

  const positiveTerms = tokens.filter(
    (token, idx) => !negatedIndices.has(idx) && !STOPWORDS.has(token) && token.length > 1,
  );

  // If stripping stopwords/negation leaves nothing (e.g. a very short
  // query), fall back to the raw non-negated tokens so we never search for
  // literally nothing.
  const fallbackTerms = tokens.filter((token, idx) => !negatedIndices.has(idx));
  const effectivePositive = positiveTerms.length > 0 ? positiveTerms : fallbackTerms;

  return {
    raw,
    positiveTerms: effectivePositive,
    negativeTerms: Array.from(negativeTerms),
    positiveQuery: effectivePositive.join(" "),
  };
}
