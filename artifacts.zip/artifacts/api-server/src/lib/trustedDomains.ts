/**
 * Curated authority signals used for de-SEO ranking.
 *
 * This is a heuristic allowlist, not a live reputation service — it exists so
 * ranking can reward encyclopedic/official/documentation sources and
 * Nepal-focused journalism over generic content-farm SEO pages, without
 * depending on a third-party ranking API.
 */
export const TRUSTED_DOMAINS: Record<string, number> = {
  "en.wikipedia.org": 1,
  "wikipedia.org": 0.95,
  "developer.mozilla.org": 0.95,
  "docs.python.org": 0.95,
  "www.python.org": 0.9,
  "nodejs.org": 0.9,
  "reactjs.org": 0.9,
  "react.dev": 0.9,
  "github.com": 0.9,
  "stackoverflow.com": 0.85,
  "www.nature.com": 0.9,
  "www.bbc.com": 0.9,
  "bbc.com": 0.9,
  "www.reuters.com": 0.9,
  "apnews.com": 0.88,
  "kathmandupost.com": 0.9,
  "www.kathmandupost.com": 0.9,
  "myrepublica.nagariknetwork.com": 0.85,
  "www.onlinekhabar.com": 0.85,
  "onlinekhabar.com": 0.85,
  "risingnepaldaily.com": 0.8,
  "www.spotlightnepal.com": 0.75,
  "www.nepalitimes.com": 0.85,
  "www.himalayantimes.com": 0.82,
  "thehimalayantimes.com": 0.82,
  "www.worldbank.org": 0.9,
  "www.who.int": 0.92,
  "www.un.org": 0.9,
  "www.gov.np": 0.9,
  "nepalarchives.gov.np": 0.85,
  "www.imf.org": 0.9,
};

const SPAM_KEYWORDS = [
  "best-deals",
  "cheap-",
  "-coupon",
  "coupon-",
  "free-download",
  "click-here",
  "top10-",
];

export function trustScoreForDomain(domain: string): number {
  const normalized = domain.replace(/^www\./, "");
  if (TRUSTED_DOMAINS[domain] !== undefined) return TRUSTED_DOMAINS[domain];
  if (TRUSTED_DOMAINS[normalized] !== undefined)
    return TRUSTED_DOMAINS[normalized];

  if (domain.endsWith(".gov.np") || domain.endsWith(".gov")) return 0.85;
  if (domain.endsWith(".edu") || domain.endsWith(".edu.np")) return 0.8;
  if (domain.endsWith(".org")) return 0.65;

  if (SPAM_KEYWORDS.some((kw) => domain.includes(kw))) return 0.15;

  return 0.5;
}

export function isTrustedDomain(domain: string): boolean {
  return trustScoreForDomain(domain) >= 0.75;
}
