import * as cheerio from "cheerio";
import crypto from "node:crypto";
import robotsParser from "robots-parser";
import { eq } from "drizzle-orm";
import { db, pagesTable, errorLogsTable, type Page } from "@workspace/db";
import { logger } from "./logger";
import { extractDomain, stripTrackingParams } from "./urlUtils";
import { trustScoreForDomain, isTrustedDomain } from "./trustedDomains";
import { embedText } from "./embeddingService";
import { pgvectorAvailable } from "./dbExtensions";

const USER_AGENT = "SupernovaSearchBot/0.1 (+https://supernova.search; privacy-focused crawler)";
const FETCH_TIMEOUT_MS = 10_000;

async function fetchWithTimeout(url: string, timeoutMs = FETCH_TIMEOUT_MS): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      headers: { "User-Agent": USER_AGENT, Accept: "text/html,application/xhtml+xml" },
      signal: controller.signal,
      redirect: "follow",
    });
  } finally {
    clearTimeout(timer);
  }
}

async function isAllowedByRobots(url: string): Promise<boolean> {
  try {
    const domain = extractDomain(url);
    const robotsUrl = `https://${domain}/robots.txt`;
    const res = await fetchWithTimeout(robotsUrl, 5000);
    if (!res.ok) return true; // no robots.txt => allowed
    const body = await res.text();
    const robots = robotsParser(robotsUrl, body);
    return robots.isAllowed(url, USER_AGENT) !== false;
  } catch {
    return true; // fail open — curated sources are trusted to be crawlable
  }
}

async function logError(message: string, url?: string) {
  logger.error({ url }, message);
  try {
    await db.insert(errorLogsTable).values({ level: "error", message, url: url ?? null });
  } catch {
    // best-effort logging only
  }
}

export interface CrawlOptions {
  contentTypeHint?: "web" | "news";
  categories?: string[];
  country?: string;
}

/**
 * Fetches a single URL, extracts metadata + text content, scores it, and
 * upserts the result into the `pages` index. Used for on-demand admin
 * submissions, RSS-discovered articles, and the curated seed crawl.
 */
export async function crawlUrl(rawUrl: string, options: CrawlOptions = {}): Promise<Page | null> {
  const url = stripTrackingParams(rawUrl);
  const domain = extractDomain(url);
  if (!domain) {
    await logError("Invalid URL, skipping crawl", rawUrl);
    return null;
  }

  const allowed = await isAllowedByRobots(url);
  if (!allowed) {
    await logError("Blocked by robots.txt", url);
    const [row] = await db
      .insert(pagesTable)
      .values({ url, domain, status: "blocked", error: "Disallowed by robots.txt" })
      .onConflictDoUpdate({
        target: pagesTable.url,
        set: { status: "blocked", error: "Disallowed by robots.txt" },
      })
      .returning();
    return row ?? null;
  }

  try {
    const response = await fetchWithTimeout(url);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    const html = await response.text();
    const $ = cheerio.load(html);

    $("script, style, noscript, svg, nav, header, footer, aside, .navbox, .infobox, .toc, #toc, .mw-editsection, .reference, sup.reference").remove();

    const title = $("title").first().text().trim() || $("h1").first().text().trim() || url;
    const firstParagraph = $("#mw-content-text p, article p, main p, p")
      .filter((_, el) => $(el).text().trim().length > 60)
      .first()
      .text()
      .trim();
    const description =
      $('meta[name="description"]').attr("content")?.trim() ||
      $('meta[property="og:description"]').attr("content")?.trim() ||
      firstParagraph.slice(0, 300) ||
      "";
    const thumbnailUrl = $('meta[property="og:image"]').attr("content")?.trim() || null;
    const language = $("html").attr("lang")?.trim().slice(0, 5) || "en";
    const publishedAtRaw =
      $('meta[property="article:published_time"]').attr("content") ||
      $("time[datetime]").first().attr("datetime") ||
      null;
    const publishedAt = publishedAtRaw ? new Date(publishedAtRaw) : null;

    const headings = $("h1, h2, h3")
      .map((_, el) => $(el).text().trim())
      .get()
      .filter(Boolean)
      .slice(0, 30);

    const mainContent = $("#mw-content-text, article, main, #content, .post-content").first();
    const bodyText = (mainContent.length ? mainContent : $("body"))
      .text()
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 20_000);

    const contentHash = crypto.createHash("sha256").update(bodyText).digest("hex");

    const trustScore = trustScoreForDomain(domain);

    // Embed title + description + a slice of the body so the semantic
    // search tier has a concept-level representation of the page, not just
    // its exact wording. Best-effort: `embedText` never throws, and if
    // pgvector isn't enabled on this database we skip generation entirely
    // rather than compute a vector nothing can use.
    const embedding = (await pgvectorAvailable())
      ? await embedText(`${title}. ${description} ${bodyText.slice(0, 1000)}`)
      : null;

    const [row] = await db
      .insert(pagesTable)
      .values({
        url,
        domain,
        title,
        description,
        content: bodyText,
        headings,
        contentType: options.contentTypeHint ?? "web",
        thumbnailUrl,
        publishedAt: publishedAt && !Number.isNaN(publishedAt.getTime()) ? publishedAt : null,
        language,
        tags: [],
        categories: options.categories ?? [],
        country: options.country ?? null,
        trustScore,
        isTrusted: isTrustedDomain(domain),
        status: "indexed",
        crawledAt: new Date(),
        contentHash,
        embedding,
        error: null,
      })
      .onConflictDoUpdate({
        target: pagesTable.url,
        set: {
          title,
          description,
          content: bodyText,
          headings,
          thumbnailUrl,
          publishedAt: publishedAt && !Number.isNaN(publishedAt.getTime()) ? publishedAt : null,
          language,
          trustScore,
          isTrusted: isTrustedDomain(domain),
          status: "indexed",
          crawledAt: new Date(),
          contentHash,
          embedding,
          error: null,
        },
      })
      .returning();

    return row ?? null;
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown crawl error";
    await logError(`Crawl failed: ${message}`, url);
    const [row] = await db
      .insert(pagesTable)
      .values({ url, domain, status: "failed", error: message })
      .onConflictDoUpdate({
        target: pagesTable.url,
        set: { status: "failed", error: message },
      })
      .returning();
    return row ?? null;
  }
}

/** Re-crawls every currently known, non-blocked page. Returns count queued. */
export async function reindexAll(): Promise<number> {
  const rows = await db
    .select({ url: pagesTable.url })
    .from(pagesTable)
    .where(eq(pagesTable.status, "indexed"));

  // Fire-and-forget with modest concurrency so the admin request returns fast.
  void (async () => {
    const CONCURRENCY = 4;
    for (let i = 0; i < rows.length; i += CONCURRENCY) {
      const batch = rows.slice(i, i + CONCURRENCY);
      await Promise.all(batch.map((r) => crawlUrl(r.url)));
    }
    logger.info({ count: rows.length }, "Full reindex complete");
  })();

  return rows.length;
}

/** Processes a small batch of queued jobs — invoked on a schedule. */
export async function processQueuedJobs(limit = 5): Promise<void> {
  const queued = await db
    .select()
    .from(pagesTable)
    .where(eq(pagesTable.status, "queued"))
    .limit(limit);

  for (const job of queued) {
    await crawlUrl(job.url);
  }
}
