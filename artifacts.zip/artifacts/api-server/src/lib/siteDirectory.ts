/**
 * Direct navigation router: maps well-known organization names, acronyms,
 * and domain fragments straight to their official homepage, so a query like
 * "mofa" or "nepal police" jumps straight to the right site instead of
 * relying purely on full-text search.
 *
 * This is a curated, hand-verified list (not a claim of exhaustive coverage
 * of every domain on the internet — no real search engine ships a static
 * table of tens of thousands of hand-checked government aliases, and faking
 * one would mean shipping broken/unverified links). It focuses on Nepal
 * government & public institutions plus major global services people type
 * as shorthand. Extend this list freely — it's a plain array, O(1) to look
 * up by alias after normalization.
 */
export interface DirectNavEntry {
  /** Aliases / acronyms / partial names that should resolve to this site. */
  aliases: string[];
  url: string;
  domain: string;
  title: string;
  description: string;
}

export const DIRECT_NAV_ENTRIES: DirectNavEntry[] = [
  // Nepal government — core
  { aliases: ["nepal government", "government of nepal", "nepal gov"], url: "https://www.nepal.gov.np", domain: "nepal.gov.np", title: "Government of Nepal", description: "Official portal of the Government of Nepal." },
  { aliases: ["mofa", "ministry of foreign affairs nepal", "mofa nepal"], url: "https://mofa.gov.np", domain: "mofa.gov.np", title: "Ministry of Foreign Affairs, Nepal", description: "Official site of Nepal's Ministry of Foreign Affairs." },
  { aliases: ["mohp", "ministry of health nepal"], url: "https://mohp.gov.np", domain: "mohp.gov.np", title: "Ministry of Health and Population, Nepal", description: "Official site of Nepal's Ministry of Health and Population." },
  { aliases: ["moe nepal", "ministry of education nepal"], url: "https://moe.gov.np", domain: "moe.gov.np", title: "Ministry of Education, Science and Technology, Nepal", description: "Official site of Nepal's Ministry of Education." },
  { aliases: ["mof nepal", "ministry of finance nepal"], url: "https://mof.gov.np", domain: "mof.gov.np", title: "Ministry of Finance, Nepal", description: "Official site of Nepal's Ministry of Finance." },
  { aliases: ["moha", "ministry of home affairs nepal"], url: "https://moha.gov.np", domain: "moha.gov.np", title: "Ministry of Home Affairs, Nepal", description: "Official site of Nepal's Ministry of Home Affairs." },
  { aliases: ["nepal police", "police nepal"], url: "https://nepalpolice.gov.np", domain: "nepalpolice.gov.np", title: "Nepal Police", description: "Official site of Nepal Police." },
  { aliases: ["nepal army", "nepali army"], url: "https://nepalarmy.mil.np", domain: "nepalarmy.mil.np", title: "Nepali Army", description: "Official site of the Nepali Army." },
  { aliases: ["ntc", "nepal telecom"], url: "https://www.ntc.net.np", domain: "ntc.net.np", title: "Nepal Telecom", description: "Official site of Nepal Telecom." },
  { aliases: ["nea", "nepal electricity authority"], url: "https://www.nea.org.np", domain: "nea.org.np", title: "Nepal Electricity Authority", description: "Official site of the Nepal Electricity Authority." },
  { aliases: ["nrb", "nepal rastra bank", "central bank nepal"], url: "https://www.nrb.org.np", domain: "nrb.org.np", title: "Nepal Rastra Bank", description: "Nepal's central bank." },
  { aliases: ["ird nepal", "inland revenue department nepal"], url: "https://ird.gov.np", domain: "ird.gov.np", title: "Inland Revenue Department, Nepal", description: "Nepal's tax authority." },
  { aliases: ["dot nepal", "department of transport nepal", "dotm"], url: "https://dotm.gov.np", domain: "dotm.gov.np", title: "Department of Transport Management, Nepal", description: "Official site of Nepal's Department of Transport Management." },
  { aliases: ["department of immigration nepal", "immigration nepal"], url: "https://www.immigration.gov.np", domain: "immigration.gov.np", title: "Department of Immigration, Nepal", description: "Official site of Nepal's Department of Immigration." },
  { aliases: ["election commission nepal", "eci nepal"], url: "https://election.gov.np", domain: "election.gov.np", title: "Election Commission, Nepal", description: "Official site of Nepal's Election Commission." },
  { aliases: ["supreme court nepal"], url: "https://supremecourt.gov.np", domain: "supremecourt.gov.np", title: "Supreme Court of Nepal", description: "Official site of the Supreme Court of Nepal." },
  { aliases: ["nepal tourism board", "ntb"], url: "https://www.ntb.gov.np", domain: "ntb.gov.np", title: "Nepal Tourism Board", description: "Official site of the Nepal Tourism Board." },
  { aliases: ["tribhuvan university", "tu nepal"], url: "https://www.tu.edu.np", domain: "tu.edu.np", title: "Tribhuvan University", description: "Nepal's oldest and largest university." },
  { aliases: ["kathmandu metropolitan city", "kmc"], url: "https://kathmandu.gov.np", domain: "kathmandu.gov.np", title: "Kathmandu Metropolitan City", description: "Official site of Kathmandu Metropolitan City." },
  { aliases: ["tribhuvan international airport", "tia nepal", "kathmandu airport"], url: "https://www.tiairport.gov.np", domain: "tiairport.gov.np", title: "Tribhuvan International Airport", description: "Nepal's main international airport." },
  // Global reference / services people navigate to by shorthand
  { aliases: ["wikipedia"], url: "https://www.wikipedia.org", domain: "wikipedia.org", title: "Wikipedia", description: "The free encyclopedia." },
  { aliases: ["gmail"], url: "https://mail.google.com", domain: "mail.google.com", title: "Gmail", description: "Google's email service." },
  { aliases: ["youtube"], url: "https://www.youtube.com", domain: "youtube.com", title: "YouTube", description: "Video sharing platform." },
  { aliases: ["github"], url: "https://github.com", domain: "github.com", title: "GitHub", description: "Software development platform." },
  { aliases: ["who", "world health organization"], url: "https://www.who.int", domain: "who.int", title: "World Health Organization", description: "United Nations health agency." },
  { aliases: ["un", "united nations"], url: "https://www.un.org", domain: "un.org", title: "United Nations", description: "International organization." },
  { aliases: ["world bank"], url: "https://www.worldbank.org", domain: "worldbank.org", title: "World Bank", description: "International financial institution." },
  { aliases: ["imf", "international monetary fund"], url: "https://www.imf.org", domain: "imf.org", title: "International Monetary Fund", description: "International financial institution." },
];

function normalize(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .replace(/\/+$/, "")
    .replace(/[^a-z0-9. ]/g, "")
    .replace(/\s+/g, " ");
}

/**
 * Resolves a raw search query to a direct-navigation target, if the query
 * is (or closely resembles) a known organization alias or domain.
 */
export function resolveDirectNav(query: string): DirectNavEntry | null {
  const normalized = normalize(query);
  if (!normalized) return null;

  for (const entry of DIRECT_NAV_ENTRIES) {
    if (normalized === normalize(entry.domain)) return entry;
    for (const alias of entry.aliases) {
      if (normalized === alias) return entry;
    }
  }
  return null;
}
