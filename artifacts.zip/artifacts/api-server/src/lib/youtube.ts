import Parser from "rss-parser";
import { db, pagesTable } from "@workspace/db";
import { logger } from "./logger";
import type { YoutubeChannelSource } from "./youtubeChannels";
import { embedText } from "./embeddingService";
import { pgvectorAvailable } from "./dbExtensions";

interface YoutubeFeedItem {
  title?: string;
  link?: string;
  pubDate?: string;
  isoDate?: string;
  ["yt:videoId"]?: string;
  ["media:group"]?: {
    ["media:description"]?: string[];
  };
}

const parser: Parser<unknown, YoutubeFeedItem> = new Parser({
  timeout: 10_000,
  customFields: {
    item: ["yt:videoId", "media:group"],
  },
});

function extractVideoId(item: YoutubeFeedItem): string | null {
  if (item["yt:videoId"]) return item["yt:videoId"];
  const match = item.link?.match(/[?&]v=([^&]+)/);
  return match?.[1] ?? null;
}

/**
 * Discovers real, currently-published videos from a YouTube channel's
 * public RSS feed and indexes them directly (title + description are
 * sufficient for full-text search; we don't attempt to scrape YouTube's
 * JS-rendered watch pages, which would violate robots.txt-style
 * expectations and mostly wouldn't yield useful HTML anyway).
 */
export async function discoverFromYoutubeChannel(
  source: YoutubeChannelSource,
  limit = 15,
): Promise<number> {
  let indexed = 0;
  try {
    const feed = await parser.parseURL(
      `https://www.youtube.com/feeds/videos.xml?channel_id=${source.channelId}`,
    );
    const items = (feed.items ?? []).slice(0, limit);

    for (const item of items) {
      const videoId = extractVideoId(item);
      if (!videoId) continue;

      const url = `https://www.youtube.com/watch?v=${videoId}`;
      const description = item["media:group"]?.["media:description"]?.[0]?.slice(0, 500) ?? "";
      const publishedAtRaw = item.isoDate ?? item.pubDate;
      const publishedAt = publishedAtRaw ? new Date(publishedAtRaw) : null;
      const embedding = (await pgvectorAvailable())
        ? await embedText(`${item.title ?? ""}. ${description}`)
        : null;

      await db
        .insert(pagesTable)
        .values({
          url,
          domain: "youtube.com",
          title: item.title ?? "",
          description,
          content: `${item.title ?? ""} ${description}`,
          contentType: "video",
          thumbnailUrl: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
          publishedAt: publishedAt && !Number.isNaN(publishedAt.getTime()) ? publishedAt : null,
          categories: source.categories ?? [],
          trustScore: 0.7,
          isTrusted: true,
          status: "indexed",
          crawledAt: new Date(),
          embedding,
        })
        .onConflictDoUpdate({
          target: pagesTable.url,
          set: {
            title: item.title ?? "",
            description,
            content: `${item.title ?? ""} ${description}`,
            thumbnailUrl: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
            publishedAt: publishedAt && !Number.isNaN(publishedAt.getTime()) ? publishedAt : null,
            status: "indexed",
            crawledAt: new Date(),
            embedding,
          },
        });

      indexed += 1;
    }
  } catch (err) {
    logger.warn({ err, channel: source.channelId }, "YouTube channel discovery failed");
  }

  return indexed;
}

export async function discoverFromYoutubeChannels(
  sources: YoutubeChannelSource[],
): Promise<number> {
  let total = 0;
  for (const source of sources) {
    total += await discoverFromYoutubeChannel(source);
  }
  return total;
}
