import type { Request, Response, NextFunction } from "express";

/**
 * Gates admin-only routes behind a shared secret.
 *
 * Accepts either:
 *  - `X-Admin-Key: <key>` header, or
 *  - `Authorization: Bearer <key>` header
 *
 * The frontend admin dashboard uses `setAuthTokenGetter` from
 * `@workspace/api-client-react`, which sends the key as a Bearer token.
 */
export function requireAdmin(req: Request, res: Response, next: NextFunction) {
  const expected = process.env["ADMIN_API_KEY"];

  if (!expected) {
    res.status(500).json({
      error: "server_misconfigured",
      message: "ADMIN_API_KEY is not configured on the server.",
    });
    return;
  }

  const headerKey = req.header("x-admin-key");
  const authHeader = req.header("authorization");
  const bearerKey = authHeader?.toLowerCase().startsWith("bearer ")
    ? authHeader.slice(7).trim()
    : undefined;

  const provided = headerKey ?? bearerKey;

  if (!provided || provided !== expected) {
    res.status(401).json({
      error: "unauthorized",
      message: "A valid admin key is required for this endpoint.",
    });
    return;
  }

  next();
}
