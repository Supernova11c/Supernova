interface PageRow {
  trustScore: number;
  language: string;
  country?: string | null;
  publishedAt: Date | null;
  crawledAt: Date | null;
  relevance?: number;
}

export interface RankingContext {
  lang?: string | undefined;
  country?: string | undefined;
  /**
   * Count of user-negated terms (e.g. "not die") found in this document.
   * We down-rank rather than exclude, so a document can still surface if
   * it's otherwise strongly relevant.
   */
  negatedTermHits?: number;
}

/**
 * `page.relevance` is expected to already be normalized to 0-1 by the
 * caller — e.g. a fused Reciprocal Rank Fusion score (lexical + semantic
 * tiers), a raw ts_rank scaled up (lexical-only path), or a trigram
 * similarity (fuzzy-fallback path). Keeping the normalization at the call
 * site (where we know which signal(s) produced the number) instead of
 * guessing a single scale factor here.
 */

const WEIGHTS = {
  relevance: 0.55,
  authority: 0.25,
  freshness: 0.12,
  languageMatch: 0.05,
  countryMatch: 0.03,
};

function freshnessScore(publishedAt: Date | null, crawledAt: Date | null): number {
  const reference = publishedAt ?? crawledAt;
  if (!reference) return 0.3;
  const ageDays = (Date.now() - reference.getTime()) / (1000 * 60 * 60 * 24);
  if (ageDays <= 1) return 1;
  if (ageDays <= 7) return 0.85;
  if (ageDays <= 30) return 0.65;
  if (ageDays <= 180) return 0.45;
  if (ageDays <= 365) return 0.3;
  return 0.15;
}

/**
 * De-SEO scoring: combines full-text relevance (from Postgres ts_rank) with
 * authority/trust, freshness, and locale-match signals so that generic
 * keyword-stuffed pages don't outrank trustworthy, on-topic sources purely
 * because they repeat the query text more often.
 */
export function scorePage(page: PageRow, ctx: RankingContext): number {
  const relevance = Math.min(1, Math.max(0, page.relevance ?? 0));
  const authority = page.trustScore;
  const freshness = freshnessScore(page.publishedAt, page.crawledAt);
  const languageMatch = ctx.lang && page.language === ctx.lang ? 1 : 0.4;
  const countryMatch =
    ctx.country && page.country === ctx.country ? 1 : ctx.country ? 0.3 : 0.6;

  const spamPenalty = page.trustScore < 0.2 ? 0.5 : 0;
  const negationPenalty = (ctx.negatedTermHits ?? 0) * 0.35;

  const score =
    relevance * WEIGHTS.relevance +
    authority * WEIGHTS.authority +
    freshness * WEIGHTS.freshness +
    languageMatch * WEIGHTS.languageMatch +
    countryMatch * WEIGHTS.countryMatch -
    spamPenalty -
    negationPenalty;

  return Math.max(0, score);
}
