export interface GeoPlace {
  name: string;
  displayName: string;
  lat: number;
  lon: number;
  type?: string | null;
}

interface NominatimResult {
  name?: string;
  display_name: string;
  lat: string;
  lon: string;
  type?: string;
}

/**
 * Proxies OpenStreetMap's Nominatim geocoder — free, no API key required.
 * We set a descriptive User-Agent as required by Nominatim's usage policy.
 */
export async function geoSearch(query: string): Promise<GeoPlace[]> {
  const url = new URL("https://nominatim.openstreetmap.org/search");
  url.searchParams.set("q", query);
  url.searchParams.set("format", "jsonv2");
  url.searchParams.set("limit", "8");

  const response = await fetch(url, {
    headers: {
      "User-Agent": "SupernovaSearch/0.1 (privacy-focused search engine)",
      Accept: "application/json",
    },
  });

  if (!response.ok) {
    throw new Error(`Nominatim request failed: ${response.status}`);
  }

  const results = (await response.json()) as NominatimResult[];

  return results.map((r) => ({
    name: r.name || r.display_name.split(",")[0] || r.display_name,
    displayName: r.display_name,
    lat: Number(r.lat),
    lon: Number(r.lon),
    type: r.type ?? null,
  }));
}
