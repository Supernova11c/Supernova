import type { FeedSource } from "./rss";

/**
 * Curated list of real RSS/Atom feeds used to keep discovering fresh, real
 * articles beyond the initial hand-picked seed list. Add more feeds here to
 * widen coverage — each one contributes real, currently-published URLs, not
 * synthetic data.
 */
export const FEED_SOURCES: FeedSource[] = [
  // Global / world news
  { url: "http://feeds.bbci.co.uk/news/world/rss.xml", categories: ["news"] },
  { url: "https://www.theguardian.com/world/rss", categories: ["news"] },
  { url: "https://feeds.npr.org/1001/rss.xml", categories: ["news"] },
  { url: "https://www.aljazeera.com/xml/rss/all.xml", categories: ["news"] },
  { url: "https://moxie.foxnews.com/google-publisher/world.xml", categories: ["news"] },
  { url: "https://feeds.skynews.com/feeds/rss/world.xml", categories: ["news"] },
  { url: "https://rss.dw.com/xml/rss-en-world", categories: ["news"] },
  // Technology
  { url: "https://hnrss.org/frontpage", categories: ["technology"] },
  { url: "https://feeds.arstechnica.com/arstechnica/index", categories: ["technology"] },
  { url: "https://www.theverge.com/rss/index.xml", categories: ["technology"] },
  { url: "https://techcrunch.com/feed/", categories: ["technology"] },
  { url: "https://www.wired.com/feed/rss", categories: ["technology"] },
  // Science
  { url: "https://www.nasa.gov/news-release/feed/", categories: ["science"] },
  { url: "https://www.sciencedaily.com/rss/all.xml", categories: ["science"] },
  { url: "https://phys.org/rss-feed/", categories: ["science"] },
  // Business
  { url: "https://feeds.content.dowjones.io/public/rss/mw_topstories", categories: ["business"] },
  // Sports
  { url: "https://www.espn.com/espn/rss/news", categories: ["sports"] },
  // Nepal
  { url: "https://kathmandupost.com/rss", categories: ["news"], country: "NP" },
  { url: "https://english.onlinekhabar.com/feed", categories: ["news"], country: "NP" },
  { url: "https://myrepublica.nagariknetwork.com/feed/", categories: ["news"], country: "NP" },
];
