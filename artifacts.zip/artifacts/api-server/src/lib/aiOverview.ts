import { logger } from "./logger";

export interface OverviewSourceInput {
  index: number;
  url: string;
  title: string;
  snippet: string;
}

export interface AiOverviewResult {
  answer: string;
  citations: { index: number; url: string; title: string }[];
  followUpQuestions: string[];
  confidence: "low" | "medium" | "high";
  grounded: boolean;
}

function fallbackOverview(
  query: string,
  sources: OverviewSourceInput[],
): AiOverviewResult {
  const top = sources.slice(0, 3);
  const answer = top.length
    ? `We couldn't reach the AI summarizer right now, but here's what the top indexed sources say about "${query}": ` +
      top.map((s) => `${s.title} [${s.index}]`).join("; ") +
      "."
    : `No AI summary is available for "${query}" right now — try browsing the results below.`;

  return {
    answer,
    citations: top.map((s) => ({ index: s.index, url: s.url, title: s.title })),
    followUpQuestions: [],
    confidence: "low",
    grounded: top.length > 0,
  };
}

/**
 * Synthesizes a cited answer from the top search results using Pollinations.ai
 * (a free, keyless, community-run inference API). Pollinations has no uptime
 * guarantee, so every call is wrapped with a timeout + graceful fallback that
 * still surfaces the raw sources instead of failing the whole request.
 */
export async function generateAiOverview(
  query: string,
  sources: OverviewSourceInput[],
): Promise<AiOverviewResult> {
  if (sources.length === 0) {
    return {
      answer: `No indexed sources were found for "${query}" yet.`,
      citations: [],
      followUpQuestions: [],
      confidence: "low",
      grounded: false,
    };
  }

  const sourceBlock = sources
    .map((s) => `[${s.index}] ${s.title}\n${s.snippet}\nURL: ${s.url}`)
    .join("\n\n");

  const systemPrompt =
    "You are Supernova Search's AI Overview. Answer the user's query in under 120 words using ONLY the numbered sources provided. " +
    "Cite sources inline using bracket numbers like [1] or [2] right after the claim they support. " +
    "Never invent facts not present in the sources. " +
    'Respond with ONLY strict JSON, no markdown fences, matching: {"answer": string, "followUpQuestions": string[] (2-3 short questions), "confidence": "low"|"medium"|"high"}.';

  const userPrompt = `Query: ${query}\n\nSources:\n${sourceBlock}`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20_000);

  try {
    const response = await fetch("https://text.pollinations.ai/openai", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      body: JSON.stringify({
        model: "openai",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        seed: 42,
      }),
    });

    if (!response.ok) {
      throw new Error(`Pollinations responded with ${response.status}`);
    }

    const payload = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
    };

    const raw = payload.choices?.[0]?.message?.content ?? "";
    const cleaned = raw.trim().replace(/^```json\s*/i, "").replace(/```$/, "");

    // Some Pollinations-backed models (reasoning models in particular) prepend
    // chain-of-thought prose before the JSON object, so extract the first
    // top-level {...} block rather than assuming the whole string is JSON.
    const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No JSON object found in AI response");
    }
    const parsed = JSON.parse(jsonMatch[0]) as {
      answer: string;
      followUpQuestions?: string[];
      confidence?: "low" | "medium" | "high";
    };

    const usedIndices = new Set<number>();
    const citationPattern = /\[(\d+)]/g;
    let match: RegExpExecArray | null;
    while ((match = citationPattern.exec(parsed.answer)) !== null) {
      usedIndices.add(Number(match[1]));
    }

    const citations = sources
      .filter((s) => usedIndices.has(s.index))
      .map((s) => ({ index: s.index, url: s.url, title: s.title }));

    return {
      answer: parsed.answer,
      citations: citations.length ? citations : sources.slice(0, 2).map((s) => ({
        index: s.index,
        url: s.url,
        title: s.title,
      })),
      followUpQuestions: parsed.followUpQuestions ?? [],
      confidence: parsed.confidence ?? "medium",
      grounded: true,
    };
  } catch (err) {
    logger.warn({ err, query }, "AI overview generation failed, using fallback");
    return fallbackOverview(query, sources);
  } finally {
    clearTimeout(timeout);
  }
}
